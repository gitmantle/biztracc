-- # A Mysql Backup System
-- # Export created: 2017/04/27 on 10:16
-- # Database : infinint_sub44
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `acats`
DROP TABLE  IF EXISTS `acats`;
CREATE TABLE `acats` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `category` varchar(40) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `acccats`
DROP TABLE  IF EXISTS `acccats`;
CREATE TABLE `acccats` (
  `acccat_id` int(11) NOT NULL AUTO_INCREMENT,
  `acccat` varchar(30) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`acccat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `access`
DROP TABLE  IF EXISTS `access`;
CREATE TABLE `access` (
  `access_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `module` char(3) NOT NULL,
  `usergroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `activities`
DROP TABLE  IF EXISTS `activities`;
CREATE TABLE `activities` (
  `activities_id` int(11) NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `ttime` char(10) NOT NULL,
  `activity` text NOT NULL,
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(25) NOT NULL,
  `contact` varchar(30) NOT NULL DEFAULT 'Other',
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`activities_id`),
  KEY `staff_id` (`staff_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`),
  FULLTEXT KEY `activity` (`activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- # Tabel structure for table `activity_status`
DROP TABLE  IF EXISTS `activity_status`;
CREATE TABLE `activity_status` (
  `activity_status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity_status` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`activity_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `address_type`
DROP TABLE  IF EXISTS `address_type`;
CREATE TABLE `address_type` (
  `address_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address_type` varchar(45) NOT NULL,
  PRIMARY KEY (`address_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `address_type` (`address_type_id`, `address_type`) VALUES (1, 'Home'), 
(2, 'Work');

-- # Tabel structure for table `addresses`
DROP TABLE  IF EXISTS `addresses`;
CREATE TABLE `addresses` (
  `address_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `location` varchar(15) NOT NULL,
  `address_type_id` int(10) unsigned NOT NULL,
  `street_no` varchar(45) NOT NULL,
  `ad1` varchar(45) NOT NULL DEFAULT '',
  `ad2` varchar(45) NOT NULL DEFAULT '',
  `suburb` varchar(45) NOT NULL DEFAULT '',
  `town` varchar(45) NOT NULL DEFAULT '',
  `state` varchar(45) NOT NULL DEFAULT '',
  `country` varchar(45) NOT NULL DEFAULT '',
  `postcode` varchar(15) NOT NULL DEFAULT '',
  `preferredp` char(1) NOT NULL DEFAULT 'N',
  `preferredv` char(1) NOT NULL DEFAULT 'N',
  `sub_id` int(11) NOT NULL,
  `billing` char(1) NOT NULL DEFAULT 'N',
  `delivery` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`address_id`),
  KEY `member_id` (`member_id`),
  KEY `suburb` (`suburb`),
  KEY `town` (`town`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `addresses` (`address_id`, `member_id`, `staff_id`, `location`, `address_type_id`, `street_no`, `ad1`, `ad2`, `suburb`, `town`, `state`, `country`, `postcode`, `preferredp`, `preferredv`, `sub_id`, `billing`, `delivery`) VALUES (2, 4, 0, 'Street', 1, '1 Bradbrook House', 'Studio Place', '', 'Kinnerton Street', 'London', '', '', 'SW1X 8EL', 'N', 'N', 0, 'Y', 'N'), 
(3, 2, 0, 'Street', 1, 'Sandhurst', 'Chart Road', '', 'Sutton Valence', 'Kent', '', 'UK', 'ME17 3AW', 'N', 'N', 0, 'Y', 'N'), 
(4, 5, 0, 'Street', 1, '40 Twisden Road', '', '', '', 'London', '', 'UK', 'NW5 1DN', 'N', 'N', 0, 'Y', 'N'), 
(5, 6, 0, 'Street', 2, 'Town & City Builders', 'Unit E Spinnaker Park', '', 'Hempstead Lane', 'Gloucester', '', '', 'GL2 5JA', 'N', 'N', 0, 'Y', 'Y'), 
(6, 7, 0, 'Street', 1, 50, 'Bisley Road', '', '', 'Stroud', '', '', 'GL5 1HF', 'N', 'N', 0, 'Y', 'Y'), 
(7, 8, 0, 'Street', 2, 45, 'Aynhoe Road', '', '', 'London', '', '', 'W14 0QA', '', '', 0, 'Y', 'Y'), 
(8, 9, 0, 'Street', 1, 'Dovedale Cottage', 'Dovedale', '', 'Blockley', 'Glos', '', '', 'GL56 9HN', '', '', 0, 'Y', 'N'), 
(9, 10, 0, 'Street', 1, 'Lillicot Farm', 'Icknield Street', '', 'Alvechurch', 'Worcestershire', '', '', 'B48 7EN', '', '', 0, 'Y', 'N'), 
(10, 11, 0, 'Street', 1, 388, 'Bristol Road', '', 'Quedgley', 'Gloucester', '', '', 'GL2 4QX', 'N', 'N', 0, 'Y', 'N'), 
(11, 13, 0, 'Street', 1, 45, 'Aynhoe Road', '', '', 'London', '', '', 'W14 0QA', '', '', 0, 'Y', 'Y');

-- # Tabel structure for table `assoc_xref`
DROP TABLE  IF EXISTS `assoc_xref`;
CREATE TABLE `assoc_xref` (
  `assoc_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `association` varchar(30) NOT NULL,
  `of_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `dependant` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`assoc_xref_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `attachments`
DROP TABLE  IF EXISTS `attachments`;
CREATE TABLE `attachments` (
  `doc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL,
  `doc` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `audit`
DROP TABLE  IF EXISTS `audit`;
CREATE TABLE `audit` (
  `audit_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `ttime` char(5) NOT NULL DEFAULT '00:00',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(45) NOT NULL,
  `userip` varchar(30) NOT NULL,
  `sub_id` tinyint(4) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(70) NOT NULL,
  `address_id` int(11) NOT NULL DEFAULT '0',
  `comms_id` int(11) NOT NULL DEFAULT '0',
  `activities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`audit_id`),
  KEY `ddate` (`ddate`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

INSERT INTO `audit` (`audit_id`, `ddate`, `ttime`, `user_id`, `uname`, `userip`, `sub_id`, `member_id`, `action`, `address_id`, `comms_id`, `activities_id`) VALUES (1, '2016-06-15', '14:57', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(2, '2016-06-15', '15:03', 61, 'Robyn Mills', '', 0, 3, 'Added member id 3', 0, 0, 0), 
(3, '2016-06-15', '17:19', 61, 'Robyn Mills', '', 44, 3, 'Edit Member', 0, 0, 0), 
(4, '2016-06-15', '17:24', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(5, '2016-06-16', '10:38', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(6, '2016-07-01', '22:45', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(7, '2016-07-04', '11:30', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(8, '2016-07-04', '12:03', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(9, '2016-07-04', '12:05', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(10, '2016-07-04', '12:07', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(11, '2016-07-04', '12:07', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(12, '2016-07-04', '12:07', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(13, '2016-07-25', '19:13', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(14, '2016-07-25', '19:16', 61, 'Robyn Mills', '', 0, 4, 'Edit Address 2', 0, 0, 0), 
(15, '2016-07-25', '19:16', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(16, '2016-07-25', '19:16', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(17, '2016-07-25', '19:17', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(18, '2016-07-25', '19:19', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(19, '2016-07-25', '19:19', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(20, '2016-07-25', '20:30', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(21, '2016-07-25', '20:32', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(22, '2016-07-25', '20:32', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(23, '2016-07-26', '07:41', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(24, '2016-07-26', '07:44', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(25, '2016-07-26', '07:44', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(26, '2016-07-26', '07:44', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(27, '2016-07-26', '07:45', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(28, '2016-07-26', '07:45', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(29, '2016-07-26', '07:45', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(30, '2016-07-26', '07:51', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(31, '2016-07-26', '07:51', 61, 'Robyn Mills', '', 0, 5, 'Edit Address 4', 0, 0, 0), 
(32, '2016-07-26', '08:42', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(33, '2016-07-26', '08:43', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(34, '2016-07-26', '08:43', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(35, '2016-07-26', '08:43', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(36, '2016-07-26', '08:43', 61, 'Robyn Mills', '', 0, 4, 'Edit Address 2', 0, 0, 0), 
(37, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(38, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(39, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(40, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 0, 2, 'Edit Address 3', 0, 0, 0), 
(41, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(42, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(43, '2016-07-26', '08:44', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(44, '2016-08-23', '20:24', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(45, '2016-08-23', '20:41', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(46, '2016-08-23', '20:42', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(47, '2016-08-23', '20:42', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(48, '2016-08-23', '20:55', 61, 'Robyn Mills', '', 44, 5, 'Edit Member', 0, 0, 0), 
(49, '2016-08-23', '20:56', 61, 'Robyn Mills', '', 0, 5, 'Edit Address 4', 0, 0, 0), 
(50, '2016-09-09', '12:46', 61, 'Robyn Mills', '', 44, 3, 'Edit Member', 0, 0, 0), 
(51, '2016-09-09', '15:15', 61, 'Robyn Mills', '', 44, 3, 'Edit Member', 0, 0, 0), 
(52, '2016-10-02', '15:56', 61, 'Robyn Mills', '', 0, 6, 'Added member id 6', 0, 0, 0), 
(53, '2016-10-02', '16:00', 61, 'Robyn Mills', '', 44, 6, 'Edit Member', 0, 0, 0), 
(54, '2016-10-02', '16:00', 61, 'Robyn Mills', '', 0, 6, 'Edit Address 5', 0, 0, 0), 
(55, '2016-10-02', '16:03', 61, 'Robyn Mills', '', 0, 7, 'Added member id 7', 0, 0, 0), 
(56, '2016-10-02', '16:08', 61, 'Robyn Mills', '', 44, 6, 'Edit Member', 0, 0, 0), 
(57, '2016-10-02', '16:10', 61, 'Robyn Mills', '', 0, 6, 'Edit Address 5', 0, 0, 0), 
(58, '2016-10-02', '16:15', 61, 'Robyn Mills', '', 44, 7, 'Edit Member', 0, 0, 0), 
(59, '2016-10-02', '16:23', 61, 'Robyn Mills', '', 44, 7, 'Edit Member', 0, 0, 0), 
(60, '2016-10-02', '16:24', 61, 'Robyn Mills', '', 0, 7, 'Edit Address 6', 0, 0, 0), 
(61, '2016-10-02', '16:26', 61, 'Robyn Mills', '', 44, 7, 'Edit Member', 0, 0, 0), 
(62, '2016-10-02', '16:29', 61, 'Robyn Mills', '', 0, 8, 'Added member id 8', 0, 0, 0), 
(63, '2016-10-02', '16:50', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(64, '2016-10-24', '14:06', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(65, '2016-10-24', '14:07', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(66, '2016-10-24', '14:11', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(67, '2016-10-25', '11:42', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(68, '2016-10-25', '11:55', 61, 'Robyn Mills', '', 44, 61, 'Edit Setup for Robin Roberts Architect', 0, 0, 0), 
(69, '2016-10-31', '12:27', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(70, '2016-10-31', '12:30', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(71, '2016-10-31', '12:30', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(72, '2016-10-31', '12:30', 61, 'Robyn Mills', '', 44, 6, 'Edit Member', 0, 0, 0), 
(73, '2016-10-31', '12:32', 61, 'Robyn Mills', '', 0, 6, 'Edit Address 5', 0, 0, 0), 
(74, '2016-10-31', '12:32', 61, 'Robyn Mills', '', 44, 6, 'Edit Member', 0, 0, 0), 
(75, '2016-10-31', '12:32', 61, 'Robyn Mills', '', 44, 6, 'Edit Member', 0, 0, 0), 
(76, '2016-10-31', '12:33', 61, 'Robyn Mills', '', 44, 8, 'Edit Member', 0, 0, 0), 
(77, '2016-10-31', '12:33', 61, 'Robyn Mills', '', 44, 8, 'Edit Member', 0, 0, 0), 
(78, '2016-10-31', '12:33', 61, 'Robyn Mills', '', 44, 8, 'Edit Member', 0, 0, 0), 
(79, '2016-10-31', '12:33', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(80, '2016-10-31', '12:34', 61, 'Robyn Mills', '', 0, 2, 'Edit Address 3', 0, 0, 0), 
(81, '2016-10-31', '12:34', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(82, '2016-10-31', '12:34', 61, 'Robyn Mills', '', 44, 2, 'Edit Member', 0, 0, 0), 
(83, '2016-10-31', '12:34', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(84, '2016-10-31', '12:34', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(85, '2016-10-31', '12:34', 61, 'Robyn Mills', '', 44, 4, 'Edit Member', 0, 0, 0), 
(86, '2016-12-05', '15:20', 61, 'Robyn Mills', '', 0, 9, 'Added member id 9', 0, 0, 0), 
(87, '2016-12-05', '15:20', 61, 'Robyn Mills', '', 44, 9, 'Edit Member', 0, 0, 0), 
(88, '2016-12-05', '15:21', 61, 'Robyn Mills', '', 44, 9, 'Edit Member', 0, 0, 0), 
(89, '2016-12-05', '15:21', 61, 'Robyn Mills', '', 44, 9, 'Edit Member', 0, 0, 0), 
(90, '2017-01-12', '09:48', 61, 'Robyn Mills', '', 0, 10, 'Added member id 10', 0, 0, 0), 
(91, '2017-01-12', '09:49', 61, 'Robyn Mills', '', 44, 10, 'Edit Member', 0, 0, 0), 
(92, '2017-01-12', '09:49', 61, 'Robyn Mills', '', 0, 10, 'Edit Communication', 0, 8, 0), 
(93, '2017-02-06', '17:15', 61, 'Robyn Mills', '', 0, 11, 'Added member id 11', 0, 0, 0), 
(94, '2017-02-07', '11:06', 61, 'Robyn Mills', '', 44, 11, 'Edit Member', 0, 0, 0), 
(95, '2017-02-07', '11:08', 61, 'Robyn Mills', '', 0, 11, 'Edit Address 10', 0, 0, 0), 
(96, '2017-02-09', '12:23', 61, 'Robyn Mills', '', 44, 11, 'Edit Member', 0, 0, 0), 
(97, '2017-02-24', '15:39', 61, 'Robyn Mills', '', 0, 12, 'Added member id 12', 0, 0, 0), 
(98, '2017-04-15', '14:34', 61, 'Robyn Mills', '', 0, 13, 'Added member id 13', 0, 0, 0);

-- # Tabel structure for table `boxes`
DROP TABLE  IF EXISTS `boxes`;
CREATE TABLE `boxes` (
  `box_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_office` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `from` mediumint(9) NOT NULL,
  `to` mediumint(9) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  `boxbag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `c_menu`
DROP TABLE  IF EXISTS `c_menu`;
CREATE TABLE `c_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `morder` smallint(4) NOT NULL,
  `level` tinyint(2) NOT NULL,
  `label` varchar(50) NOT NULL DEFAULT '',
  `onclick` text,
  `tooltip` varchar(250) NOT NULL DEFAULT '',
  `image_file` blob NOT NULL,
  `facility` char(2) NOT NULL DEFAULT '',
  `a1` char(1) NOT NULL DEFAULT 'N',
  `a2` char(1) NOT NULL DEFAULT 'N',
  `a3` char(1) NOT NULL DEFAULT 'N',
  `a4` char(1) NOT NULL DEFAULT 'N',
  `a5` char(1) NOT NULL DEFAULT 'N',
  `a6` char(1) NOT NULL DEFAULT 'N',
  `a7` char(1) NOT NULL DEFAULT 'N',
  `a8` char(1) NOT NULL DEFAULT 'N',
  `a9` char(1) NOT NULL DEFAULT 'N',
  `a10` char(1) NOT NULL DEFAULT 'N',
  `a11` char(1) NOT NULL DEFAULT 'N',
  `a12` char(1) NOT NULL DEFAULT 'N',
  `a13` char(1) NOT NULL DEFAULT 'N',
  `a14` char(1) NOT NULL DEFAULT 'N',
  `a15` char(1) NOT NULL DEFAULT 'N',
  `a16` char(1) NOT NULL DEFAULT 'N',
  `a17` char(1) NOT NULL DEFAULT 'N',
  `a18` char(1) NOT NULL DEFAULT 'N',
  `a19` char(1) NOT NULL DEFAULT 'N',
  `a20` char(1) NOT NULL DEFAULT 'Y',
  `std_sub` char(1) NOT NULL DEFAULT 'N',
  `extra_1` char(1) NOT NULL DEFAULT 'N',
  `extra_2` char(1) NOT NULL DEFAULT 'N',
  `extra_3` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `c_menu` (`menu_id`, `morder`, `level`, `label`, `onclick`, `tooltip`, `image_file`, `facility`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `a7`, `a8`, `a9`, `a10`, `a11`, `a12`, `a13`, `a14`, `a15`, `a16`, `a17`, `a18`, `a19`, `a20`, `std_sub`, `extra_1`, `extra_2`, `extra_3`) VALUES (1, 1, 0, 'Members', '', 'Clients Menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'N', 'N', 'Y'), 
(3, 3, 1, 'Administer Members', 'javascript:createTab(\'updtmembers.php\',\'Add/Edit/Delete Member Records\',0)', 'Add/Edit/Delete Member Records', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(5, 5, 0, 'Marketing', '', 'Marketing Functions', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'Y'), 
(6, 6, 1, 'Campaign Administration', '', 'Campaign Functions', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(7, 7, 2, 'Update Campaigns', 'javascript:createTab(\'updtcampaigns.php\',\'Update Campaign Data\',0)', 'Update Campaign Data', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(8, 8, 2, 'Run Campaign', 'javascript:createTab(\'runcampaign.php\',\'Run a Campaign\',0)', 'Run a Campaign', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(9, 9, 2, 'Update Outsource Providers', 'javascript:createTab(\'updtoutprov.php\',\'Add/Edit/Delete Outsoruce Providers\',0)', 'Add/Edit/Delete Outsoruce Providers', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(10, 10, 2, 'Campaign Statistics', '', 'Report on campaign statistics', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(11, 11, 3, 'By Campaign/Outsource', 'javascript:createTab(\'campstats.php\',\'Report on campaign statistics by campaign/outsource\',0)', 'Report on campaign statistics by campaign/outsource', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(12, 12, 2, 'Update Marketers', 'javascript:createTab(\'updtmarketers.php\',\'Add/Edit/Delete Marketers and their Staff\',0)', 'Add/Edit/Delete Marketers and their Staff', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'N', 'N', 'Y'), 
(13, 13, 0, 'Administrative Tools', '', 'Administrative Tools Menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(14, 14, 1, 'Update Workflow Stages', 'javascript:createTab(\'updtworkflow.php\',\'Update Workflow Stages\',0)', 'Update list of workflow stages', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(15, 15, 1, 'Duplicate Member Records', 'javascript:createTab(\'listduplicates.php\',\'List Duplicate member records\',0)', 'List Duplicate member records', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(16, 16, 1, 'Update Client Types', 'javascript:createTab(\'updtclienttypes.php\',\'Update Client Types\',0)', 'Update Client Types', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(17, 17, 1, 'Update Industries', 'javascript:createTab(\'updtindustries.php\',\'Update Industry Types\',0)', 'Update Industry Types', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(18, 18, 1, 'Update Accounting Categories', 'javascript:createTab(\'updtacccats.php\',\'Update Accounting Categories\',0)', 'Update Accounting Categories', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(19, 19, 0, 'Complaints Register', '', '', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(20, 20, 1, 'Administer Complaints', 'javascript:createTab(\'complaints.php\',\'List and update complaints\',0)', 'List and update complaints', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(21, 21, 0, 'Housekeeping', '', 'Housekeeping menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(22, 22, 1, 'Setup Company Details', 'javascript:createTab(\'../fin/hs_setup.php\',\'Setup Company Details\',0)', 'Setup Company Details', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(23, 23, 1, 'Update Users', 'javascript:createTab(\'hs_users.php\',\'Update users\',0)', 'Assign passwords to users and users to menu groups.', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(24, 24, 1, 'Update Menu Groups', 'javascript:createTab(\'hs_updtmeng.php\',\'Update Menu Groups\',0)', 'Assign menu options to groups of users.', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(25, 25, 1, 'Backup', 'javascript:createTab(\'../includes/bkup/backup.php\',\'Backup\',0)', 'Backup database for this company', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(26, 26, 1, 'Restore', 'javascript:createTab(\'../includes/bkup/rbkup.php\',\'Restore from Backup\',0)', 'Restore from backup', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', '');

-- # Tabel structure for table `campaign_costs`
DROP TABLE  IF EXISTS `campaign_costs`;
CREATE TABLE `campaign_costs` (
  `costs_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `item` varchar(70) NOT NULL,
  `cost` decimal(16,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`costs_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `campaign_docs`
DROP TABLE  IF EXISTS `campaign_docs`;
CREATE TABLE `campaign_docs` (
  `campdoc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date NOT NULL,
  `doc` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`campdoc_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `campaigns`
DROP TABLE  IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `campaign_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(45) NOT NULL,
  `startdate` date NOT NULL DEFAULT '0000-00-00',
  `staff` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `goals` text NOT NULL,
  `outprov_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`campaign_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `candidates`
DROP TABLE  IF EXISTS `candidates`;
CREATE TABLE `candidates` (
  `candidate_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `cand_status` char(1) NOT NULL DEFAULT 'A',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `lastname` varchar(45) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `preferred` varchar(50) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `workflow` varchar(45) NOT NULL,
  `candstatus` varchar(10) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`candidate_id`),
  KEY `sub_id` (`sub_id`),
  KEY `member_id` (`member_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `client_company_xref`
DROP TABLE  IF EXISTS `client_company_xref`;
CREATE TABLE `client_company_xref` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL DEFAULT '0',
  `company_id` int(10) unsigned NOT NULL DEFAULT '0',
  `drno` int(10) unsigned NOT NULL DEFAULT '0',
  `crno` int(10) unsigned NOT NULL DEFAULT '0',
  `drsub` int(2) NOT NULL DEFAULT '0',
  `crsub` int(2) NOT NULL DEFAULT '0',
  `subname` varchar(45) NOT NULL DEFAULT '',
  `hs_contractor` int(11) NOT NULL DEFAULT '0',
  `blocked` char(3) NOT NULL DEFAULT 'No',
  `sortcode` varchar(45) NOT NULL DEFAULT '',
  `current` double(16,2) NOT NULL DEFAULT '0.00',
  `d30` double(16,2) NOT NULL DEFAULT '0.00',
  `d60` double(16,2) NOT NULL DEFAULT '0.00',
  `d90` double(16,2) NOT NULL DEFAULT '0.00',
  `d120` double(16,2) NOT NULL DEFAULT '0.00',
  `tcur` double(16,2) NOT NULL DEFAULT '0.00',
  `t30` double(16,2) NOT NULL DEFAULT '0.00',
  `t60` double(16,2) NOT NULL DEFAULT '0.00',
  `t90` double(16,2) NOT NULL DEFAULT '0.00',
  `t120` double(16,2) NOT NULL DEFAULT '0.00',
  `limit` int(4) NOT NULL,
  `monlimit` double(16,2) NOT NULL DEFAULT '0.00',
  `sellprice` int(4) NOT NULL,
  `priceband` int(11) NOT NULL DEFAULT '1',
  `sendstatement` char(5) NOT NULL DEFAULT 'Post',
  `billing` int(11) NOT NULL DEFAULT '0',
  `email` int(11) NOT NULL DEFAULT '0',
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `member` varchar(75) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `client_company_xref` (`uid`, `client_id`, `company_id`, `drno`, `crno`, `drsub`, `crsub`, `subname`, `hs_contractor`, `blocked`, `sortcode`, `current`, `d30`, `d60`, `d90`, `d120`, `tcur`, `t30`, `t60`, `t90`, `t120`, `limit`, `monlimit`, `sellprice`, `priceband`, `sendstatement`, `billing`, `email`, `lastupdated`, `member`) VALUES (4, 1, 26, 0, 20000001, 0, 0, '', 0, 'No', 'Mills20000001-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2017-02-08 02:23:27', 'Robyn Mills'), 
(5, 2, 26, 30000002, 0, 0, 0, '', 0, 'No', 'Scragg30000002-0', 363.25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 3, 0, '2017-04-15 23:28:16', 'Chris Scragg'), 
(7, 4, 26, 30000004, 0, 0, 0, '', 0, 'No', 'Campbell30000004-0', -443.7, 2375, -1071.2, -1572.45, 2643.65, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 2, 0, '2017-04-27 19:01:47', 'Neil Campbell'), 
(8, 5, 26, 30000005, 0, 0, 0, '', 0, 'No', 'Roberts30000005-0', 1506.3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 4, 0, '2017-04-15 23:30:21', 'Toby Roberts'), 
(9, 6, 26, 30000006, 0, 0, 0, '', 0, 'No', 'Donaldson30000006-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 5, 0, '2017-04-27 19:01:47', 'Matt Donaldson'), 
(10, 7, 26, 30000007, 0, 0, 0, '', 0, 'No', 'Hopkins30000007-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 6, 0, '2017-03-16 20:14:50', 'Dave Hopkins'), 
(11, 8, 26, 30000008, 0, 0, 0, '', 0, 'No', 'Chestermead Ltd30000008-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2017-04-27 19:01:47', 'Chestermead Ltd'), 
(12, 9, 26, 30000009, 0, 0, 0, '', 0, 'No', 'Salmons30000009-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2017-04-27 19:01:47', 'Roger Salmons'), 
(13, 10, 26, 30000010, 0, 0, 0, '', 0, 'No', 'Wentworth30000010-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2017-04-27 19:01:47', 'Vicki Wentworth'), 
(14, 11, 26, 30000011, 0, 0, 0, '', 0, 'No', 'Crook30000011-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 10, 0, '2017-04-27 19:01:47', 'Ian Crook'), 
(15, 12, 26, 0, 20000012, 0, 0, '', 0, 'No', 'Roberts Personal20000012-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2017-03-16 20:14:50', 'Robin Roberts Personal'), 
(16, 13, 26, 30000013, 0, 0, 0, '', 0, 'No', 'Birtwistle30000013-0', 765.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2017-04-27 19:01:47', 'Sue Birtwistle');

-- # Tabel structure for table `client_types`
DROP TABLE  IF EXISTS `client_types`;
CREATE TABLE `client_types` (
  `client_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_type` varchar(15) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`client_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `clienttype_xref`
DROP TABLE  IF EXISTS `clienttype_xref`;
CREATE TABLE `clienttype_xref` (
  `clienttype_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `client_type` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`clienttype_xref_id`),
  KEY `member_id` (`member_id`,`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `comms`
DROP TABLE  IF EXISTS `comms`;
CREATE TABLE `comms` (
  `comms_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `comms_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `country_code` varchar(4) NOT NULL,
  `area_code` varchar(4) NOT NULL DEFAULT ' ',
  `comm` varchar(75) NOT NULL DEFAULT ' ',
  `comm2` varchar(75) NOT NULL,
  `preferred` char(1) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `billing` char(1) NOT NULL DEFAULT 'N',
  `delivery` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`comms_id`),
  KEY `member_id` (`member_id`),
  KEY `comm2` (`comm2`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `comms` (`comms_id`, `member_id`, `staff_id`, `comms_type_id`, `country_code`, `area_code`, `comm`, `comm2`, `preferred`, `sub_id`, `billing`, `delivery`) VALUES (1, 2, 0, 2, '', '', '', '', '', 0, '', 'N'), 
(2, 3, 0, 3, 0, 44, 7933333, 7933333, '', 0, '', 'N'), 
(3, 5, 0, 1, 44, 1453, 111, 111, '', 0, '', 'N'), 
(4, 6, 0, 0, '', '', '', '', '', 0, '', 'N'), 
(5, 7, 0, 0, '', '', '', '', '', 0, '', 'N'), 
(6, 8, 0, 0, '', '', '', '', '', 0, '', 'N'), 
(7, 9, 0, 0, '', '', '', '', '', 0, '', 'N'), 
(8, 10, 0, 1, '00 4', 138, 755493, 755493, '', 0, 'N', 'N'), 
(9, 11, 0, 2, 44, 145, 111, 111, '', 0, '', 'N'), 
(10, 12, 0, 3, 0, 1452, 812512, 812512, '', 0, '', 'N'), 
(11, 13, 0, 1, '00 4', 208, 1, 1, '', 0, '', 'N');

-- # Tabel structure for table `comms_type`
DROP TABLE  IF EXISTS `comms_type`;
CREATE TABLE `comms_type` (
  `comms_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comm_type` varchar(45) NOT NULL,
  PRIMARY KEY (`comms_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `comms_type` (`comms_type_id`, `comm_type`) VALUES (1, 'Phone Home'), 
(2, 'Phone Work'), 
(3, 'Mobile'), 
(4, 'Email'), 
(5, 'Skype'), 
(6, 'Fax Work'), 
(7, 'Fax Home'), 
(8, 'After Hours'), 
(9, 'Facebook'), 
(10, 'Twitter'), 
(11, 'Web');

-- # Tabel structure for table `companies`
DROP TABLE  IF EXISTS `companies`;
CREATE TABLE `companies` (
  `company_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) NOT NULL,
  `db_name` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `business_number` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `complaint_nature`
DROP TABLE  IF EXISTS `complaint_nature`;
CREATE TABLE `complaint_nature` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `nature` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `complaint_nature` (`uid`, `nature`) VALUES (1, 'Customer Service'), 
(2, 'Faulty Item');

-- # Tabel structure for table `complaints`
DROP TABLE  IF EXISTS `complaints`;
CREATE TABLE `complaints` (
  `complaint_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `complainant` varchar(50) NOT NULL,
  `against` varchar(50) NOT NULL,
  `received` date NOT NULL DEFAULT '0000-00-00',
  `via` varchar(20) NOT NULL,
  `acknowledged` date NOT NULL DEFAULT '0000-00-00',
  `closed` date NOT NULL DEFAULT '0000-00-00',
  `compensation` decimal(16,2) NOT NULL DEFAULT '0.00',
  `medium` varchar(50) NOT NULL,
  `source` varchar(50) NOT NULL,
  `nature` varchar(50) NOT NULL,
  `product` varchar(100) NOT NULL,
  `taken_by` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `outcome` text NOT NULL,
  `notes` text NOT NULL,
  `responded` date NOT NULL DEFAULT '0000-00-00',
  `cause` varchar(100) NOT NULL,
  `further_action` text NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `documents`
DROP TABLE  IF EXISTS `documents`;
CREATE TABLE `documents` (
  `doc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date NOT NULL,
  `doc` varchar(100) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`doc_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `emails`
DROP TABLE  IF EXISTS `emails`;
CREATE TABLE `emails` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `email_date` date NOT NULL DEFAULT '0000-00-00',
  `email_from` varchar(45) NOT NULL,
  `email_subject` varchar(45) NOT NULL,
  `email_message` text NOT NULL,
  `email_time` char(8) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `emails2send`
DROP TABLE  IF EXISTS `emails2send`;
CREATE TABLE `emails2send` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email_date` date NOT NULL DEFAULT '0000-00-00',
  `email_from` varchar(70) NOT NULL,
  `email_to` varchar(70) NOT NULL,
  `cc` varchar(300) NOT NULL,
  `email_subject` varchar(70) NOT NULL,
  `email_message` text NOT NULL,
  `sent` char(1) NOT NULL DEFAULT 'N',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `email_date` (`email_date`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `industries`
DROP TABLE  IF EXISTS `industries`;
CREATE TABLE `industries` (
  `industry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `industry` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`industry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `links`
DROP TABLE  IF EXISTS `links`;
CREATE TABLE `links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `members`
DROP TABLE  IF EXISTS `members`;
CREATE TABLE `members` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alt_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(45) NOT NULL DEFAULT '',
  `middlename` varchar(45) NOT NULL,
  `preferredname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL DEFAULT '',
  `dob` date NOT NULL,
  `gender` char(6) NOT NULL,
  `title` char(9) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `client_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `age` smallint(3) unsigned NOT NULL,
  `checked` char(3) NOT NULL DEFAULT 'No',
  `occupation` varchar(45) NOT NULL,
  `industry_id` int(11) NOT NULL,
  `position` varchar(45) NOT NULL,
  `dependant` char(1) NOT NULL DEFAULT 'N',
  `staff` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `next_meeting` date NOT NULL DEFAULT '0000-00-00',
  `client_type` varchar(20) NOT NULL,
  PRIMARY KEY (`member_id`),
  KEY `lastname` (`lastname`),
  KEY `dob` (`dob`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `members` (`member_id`, `alt_id`, `firstname`, `middlename`, `preferredname`, `lastname`, `dob`, `gender`, `title`, `sub_id`, `client_type_id`, `age`, `checked`, `occupation`, `industry_id`, `position`, `dependant`, `staff`, `status`, `next_meeting`, `client_type`) VALUES (1, 0, 'Robyn', '', '', 'Mills', '0000-00-00', 'Female', 'Ms', 44, 0, 0, 'No', 'Bookkeeper', 0, '', 'N', 0, '', '0000-00-00', ''), 
(2, 0, 'Chris', '', '', 'Scragg', '0000-00-00', 'Male', 'Mr', 44, 0, 2016, 'No', '', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(3, 0, '', '', '', 'Shadow', '0000-00-00', '', '', 0, 0, 0, 'No', '', 0, '', 'N', '', '', '0000-00-00', ''), 
(4, 0, 'Neil', '', 'Mr and Mrs Neil Campbell', 'Campbell', '0000-00-00', 'Male', 'Mr', 44, 0, 2016, 'No', 'Domestic', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(5, 0, 'Toby', '', 'Toby Roberts and Daphne Tagg', 'Roberts', '0000-00-00', 'Male', 'Mr', 44, 0, 2016, 'No', '', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(6, 0, 'Matt', '', 'Matt Donaldson', 'Donaldson', '0000-00-00', 'Male', 'Mr', 44, 0, 2016, 'No', '', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(7, 0, 'Dave', '', 'Dave and Marian Hopkins', 'Hopkins', '0000-00-00', 'Male', 'Mr', 44, 0, 0, 'No', '', 0, '', 'N', 'Robyn Mills', 'Lead', '0000-00-00', ''), 
(8, 0, '', '', 'Chestermead Ltd', 'Chestermead Ltd', '0000-00-00', 'Male', 'Mr', 44, 0, 2016, 'No', '', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(9, 0, 'Roger', '', 'Mr and Mrs R Salmons', 'Salmons', '0000-00-00', 'Male', 'Mr', 44, 0, 2016, 'No', '', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(10, 0, 'Vicki', '', '', 'Wentworth', '0000-00-00', 'Female', 'Ms', 44, 0, 0, 'No', '', 0, '', 'N', 0, 'Client', '0000-00-00', ''), 
(11, 0, 'Ian', '', 'Ian Crook & Gemma Carman', 'Crook', '0000-00-00', 'Male', 'Mr', 44, 0, 0, 'No', '', 0, '', 'N', 0, 'Client', '0000-00-00', ''), 
(12, 0, 'Robin', '', 'Robin Roberts (Personal)', 'Roberts Personal', '0000-00-00', 'Male', 'Mr', 44, 0, 0, 'No', '', 0, '', 'N', 0, 'Lead', '0000-00-00', ''), 
(13, 0, 'Sue', '', '', 'Birtwistle', '0000-00-00', 'Female', 'Ms', 44, 0, 0, 'No', '', 0, '', 'N', 0, 'Client', '0000-00-00', '');

-- # Tabel structure for table `outprovs`
DROP TABLE  IF EXISTS `outprovs`;
CREATE TABLE `outprovs` (
  `outprov_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `phone` varchar(30) NOT NULL,
  `address` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `web` varchar(70) NOT NULL,
  PRIMARY KEY (`outprov_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `quotelines`
DROP TABLE  IF EXISTS `quotelines`;
CREATE TABLE `quotelines` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL DEFAULT '0',
  `itemcode` varchar(30) NOT NULL,
  `quantity` decimal(9,3) NOT NULL DEFAULT '0.000',
  `price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `taxtype` char(3) NOT NULL DEFAULT '',
  `taxpcent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(16,2) NOT NULL DEFAULT '0.00',
  `taxindex` int(11) NOT NULL,
  `disc_type` char(1) NOT NULL DEFAULT '',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `ref_no` char(15) NOT NULL,
  `item` varchar(45) NOT NULL DEFAULT '',
  `unit` char(4) NOT NULL DEFAULT '',
  `value` decimal(16,2) NOT NULL DEFAULT '0.00',
  `supplier` int(11) NOT NULL DEFAULT '0',
  `currency` char(3) NOT NULL DEFAULT '',
  `sub` int(11) NOT NULL DEFAULT '0',
  `consign` char(1) NOT NULL DEFAULT '',
  `rate` decimal(7,3) NOT NULL DEFAULT '0.000',
  `grnlineno` int(11) NOT NULL,
  `paid` decimal(16,2) NOT NULL DEFAULT '0.00',
  `note` text NOT NULL,
  `sent` decimal(16,2) NOT NULL DEFAULT '0.00',
  `dn` varchar(15) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `quotes`
DROP TABLE  IF EXISTS `quotes`;
CREATE TABLE `quotes` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `coy_id` int(11) NOT NULL DEFAULT '0',
  `accountno` int(11) NOT NULL DEFAULT '0',
  `branch` char(4) NOT NULL DEFAULT '',
  `sub` int(11) NOT NULL DEFAULT '0',
  `gldesc` char(40) NOT NULL DEFAULT '',
  `invno` int(11) NOT NULL DEFAULT '0',
  `ref_no` char(15) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `totvalue` double(16,2) NOT NULL DEFAULT '0.00',
  `tax` double(16,2) NOT NULL DEFAULT '0.00',
  `cash` double(16,2) NOT NULL DEFAULT '0.00',
  `cheque` double(16,2) NOT NULL DEFAULT '0.00',
  `eftpos` double(16,2) NOT NULL DEFAULT '0.00',
  `ccard` double(16,2) NOT NULL DEFAULT '0.00',
  `staff` varchar(45) NOT NULL,
  `xref` char(15) NOT NULL DEFAULT '',
  `postaladdress` varchar(100) NOT NULL,
  `deliveryaddress` varchar(100) NOT NULL,
  `client` varchar(80) NOT NULL,
  `note` text NOT NULL,
  `coyname` varchar(50) NOT NULL,
  `invref` varchar(15) NOT NULL,
  `currency` char(3) NOT NULL,
  `rate` decimal(7,3) NOT NULL DEFAULT '1.000',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referrals`
DROP TABLE  IF EXISTS `referrals`;
CREATE TABLE `referrals` (
  `referral_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(10) DEFAULT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `middlename` varchar(45) DEFAULT NULL,
  `preferred` varchar(45) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `commtype` int(11) NOT NULL DEFAULT '0',
  `country` varchar(45) DEFAULT NULL,
  `area` varchar(10) DEFAULT NULL,
  `comm` varchar(80) DEFAULT NULL,
  `commtype2` int(11) NOT NULL,
  `country2` varchar(45) DEFAULT NULL,
  `area2` varchar(10) DEFAULT NULL,
  `comm2` varchar(80) DEFAULT NULL,
  `location` varchar(20) DEFAULT NULL,
  `addresstype` int(11) NOT NULL DEFAULT '0',
  `streetno` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `suburb` varchar(50) DEFAULT NULL,
  `town` varchar(50) DEFAULT NULL,
  `postcode` varchar(6) DEFAULT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date DEFAULT NULL,
  `referred_id` int(11) NOT NULL DEFAULT '0',
  `phoned` char(3) NOT NULL DEFAULT 'No',
  `phcounted` char(1) NOT NULL DEFAULT 'N',
  `note` text NOT NULL,
  PRIMARY KEY (`referral_id`),
  KEY `lastname` (`lastname`),
  KEY `comm` (`comm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referrals_phone`
DROP TABLE  IF EXISTS `referrals_phone`;
CREATE TABLE `referrals_phone` (
  `ref_phone_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL,
  `ttime` char(11) NOT NULL,
  `referral_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ref_phone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referred`
DROP TABLE  IF EXISTS `referred`;
CREATE TABLE `referred` (
  `referred_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referred` varchar(25) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`referred_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `rural`
DROP TABLE  IF EXISTS `rural`;
CREATE TABLE `rural` (
  `rural_id` int(11) NOT NULL AUTO_INCREMENT,
  `rd` mediumint(9) NOT NULL,
  `town` varchar(100) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  PRIMARY KEY (`rural_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `sayings`
DROP TABLE  IF EXISTS `sayings`;
CREATE TABLE `sayings` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `heading` varchar(45) NOT NULL,
  `saying` varchar(400) NOT NULL,
  `credit` varchar(45) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `status`
DROP TABLE  IF EXISTS `status`;
CREATE TABLE `status` (
  `status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `streets`
DROP TABLE  IF EXISTS `streets`;
CREATE TABLE `streets` (
  `street_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `street` varchar(45) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `area` varchar(45) NOT NULL,
  `postcode` varchar(4) NOT NULL,
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `subemails`
DROP TABLE  IF EXISTS `subemails`;
CREATE TABLE `subemails` (
  `subemail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(70) NOT NULL,
  `recipient` varchar(70) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`subemail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `tmp18_assocfile`
DROP TABLE  IF EXISTS `tmp18_assocfile`;
CREATE TABLE `tmp18_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `todo`
DROP TABLE  IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enter_date` date NOT NULL,
  `enter_staff` varchar(45) NOT NULL,
  `todo_by` varchar(45) NOT NULL,
  `complete_by` date NOT NULL,
  `task` varchar(250) NOT NULL,
  `done` char(3) NOT NULL DEFAULT 'No',
  `category` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`todo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `todo` (`todo_id`, `enter_date`, `enter_staff`, `todo_by`, `complete_by`, `task`, `done`, `category`, `sub_id`) VALUES (1, '2016-06-10', 'Robyn Mills', 'Robyn Mills', '2016-06-13', 'Collect invoices', 'Yes', 'High Priority', 44), 
(2, '2016-07-21', 'Robyn Mills', 'Robyn Mills', '2016-08-01', 'Process any outward invoices for end July 16', 'Yes', 'Standard', 44);

-- # Tabel structure for table `workflow`
DROP TABLE  IF EXISTS `workflow`;
CREATE TABLE `workflow` (
  `process_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `process` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `porder` int(10) NOT NULL DEFAULT '0',
  `aide_memoir` text NOT NULL,
  PRIMARY KEY (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `workflow_xref`
DROP TABLE  IF EXISTS `workflow_xref`;
CREATE TABLE `workflow_xref` (
  `workflow_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `process` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`workflow_xref_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`),
  KEY `process` (`process`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp34_tasks`
DROP TABLE  IF EXISTS `ztmp34_tasks`;
CREATE TABLE `ztmp34_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp36_tasks`
DROP TABLE  IF EXISTS `ztmp36_tasks`;
CREATE TABLE `ztmp36_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp61_assocfile`
DROP TABLE  IF EXISTS `ztmp61_assocfile`;
CREATE TABLE `ztmp61_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp61_tasks`
DROP TABLE  IF EXISTS `ztmp61_tasks`;
CREATE TABLE `ztmp61_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp68_tasks`
DROP TABLE  IF EXISTS `ztmp68_tasks`;
CREATE TABLE `ztmp68_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

SET FOREIGN_KEY_CHECKS = 1; 
COMMIT; 
SET AUTOCOMMIT = 1; 
