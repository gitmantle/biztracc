-- # A Mysql Backup System
-- # Export created: 2016/12/13 on 07:38
-- # Database : infinint_sub41
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `acats`
DROP TABLE  IF EXISTS `acats`;
CREATE TABLE `acats` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `category` varchar(40) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `acccats`
DROP TABLE  IF EXISTS `acccats`;
CREATE TABLE `acccats` (
  `acccat_id` int(11) NOT NULL AUTO_INCREMENT,
  `acccat` varchar(30) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`acccat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `access`
DROP TABLE  IF EXISTS `access`;
CREATE TABLE `access` (
  `access_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `module` char(3) NOT NULL,
  `usergroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `activities`
DROP TABLE  IF EXISTS `activities`;
CREATE TABLE `activities` (
  `activities_id` int(11) NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `ttime` char(10) NOT NULL,
  `activity` text NOT NULL,
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(25) NOT NULL,
  `contact` varchar(30) NOT NULL DEFAULT 'Other',
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`activities_id`),
  KEY `staff_id` (`staff_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`),
  FULLTEXT KEY `activity` (`activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- # Tabel structure for table `activity_status`
DROP TABLE  IF EXISTS `activity_status`;
CREATE TABLE `activity_status` (
  `activity_status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity_status` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`activity_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `address_type`
DROP TABLE  IF EXISTS `address_type`;
CREATE TABLE `address_type` (
  `address_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address_type` varchar(45) NOT NULL,
  PRIMARY KEY (`address_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `address_type` (`address_type_id`, `address_type`) VALUES (1, 'Home'), 
(2, 'Work');

-- # Tabel structure for table `addresses`
DROP TABLE  IF EXISTS `addresses`;
CREATE TABLE `addresses` (
  `address_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `location` varchar(15) NOT NULL,
  `address_type_id` int(10) unsigned NOT NULL,
  `street_no` varchar(45) NOT NULL,
  `ad1` varchar(45) NOT NULL DEFAULT '',
  `ad2` varchar(45) NOT NULL DEFAULT '',
  `suburb` varchar(45) NOT NULL DEFAULT '',
  `town` varchar(45) NOT NULL DEFAULT '',
  `state` varchar(45) NOT NULL DEFAULT '',
  `country` varchar(45) NOT NULL DEFAULT '',
  `postcode` varchar(15) NOT NULL DEFAULT '',
  `preferredp` char(1) NOT NULL DEFAULT 'N',
  `preferredv` char(1) NOT NULL DEFAULT 'N',
  `sub_id` int(11) NOT NULL,
  `billing` char(1) NOT NULL DEFAULT 'N',
  `delivery` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`address_id`),
  KEY `member_id` (`member_id`),
  KEY `suburb` (`suburb`),
  KEY `town` (`town`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `addresses` (`address_id`, `member_id`, `staff_id`, `location`, `address_type_id`, `street_no`, `ad1`, `ad2`, `suburb`, `town`, `state`, `country`, `postcode`, `preferredp`, `preferredv`, `sub_id`, `billing`, `delivery`) VALUES (1, 18, 0, 'Street', 2, 2, 'Radiata Street', '', '', 'Maroochydore', '', '', 4558, '', '', 0, 'N', 'N'), 
(2, 19, 0, 'Street', 2, 1, 'Wises St', '', '', 'Maroochydore', '', '', 4559, '', '', 0, 'N', 'N'), 
(3, 20, 0, 'Street', 2, 21, 'Sugar Road', '', '', 'Maroochydore', '', '', 4559, '', '', 0, 'N', 'N'), 
(4, 21, 0, 'Street', 2, 1, 'Fisher Place', '', 'Indooripilly', 'Brisbane', '', '', '', '', '', 0, 'N', 'N');

-- # Tabel structure for table `assoc_xref`
DROP TABLE  IF EXISTS `assoc_xref`;
CREATE TABLE `assoc_xref` (
  `assoc_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `association` varchar(30) NOT NULL,
  `of_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `dependant` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`assoc_xref_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `attachments`
DROP TABLE  IF EXISTS `attachments`;
CREATE TABLE `attachments` (
  `doc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL,
  `doc` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `audit`
DROP TABLE  IF EXISTS `audit`;
CREATE TABLE `audit` (
  `audit_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `ttime` char(5) NOT NULL DEFAULT '00:00',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(45) NOT NULL,
  `userip` varchar(30) NOT NULL,
  `sub_id` tinyint(4) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(70) NOT NULL,
  `address_id` int(11) NOT NULL DEFAULT '0',
  `comms_id` int(11) NOT NULL DEFAULT '0',
  `activities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`audit_id`),
  KEY `ddate` (`ddate`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `audit` (`audit_id`, `ddate`, `ttime`, `user_id`, `uname`, `userip`, `sub_id`, `member_id`, `action`, `address_id`, `comms_id`, `activities_id`) VALUES (1, '2015-01-11', '16:04', 56, 'Robyn Mills', '', 0, 1, 'Added member id 1', 0, 0, 0), 
(2, '2015-01-11', '16:06', 56, 'Robyn Mills', '', 0, 2, 'Added member id 2', 0, 0, 0), 
(3, '2015-01-11', '16:07', 56, 'Robyn Mills', '', 0, 3, 'Added member id 3', 0, 0, 0), 
(4, '2015-01-11', '16:09', 56, 'Robyn Mills', '', 0, 4, 'Added member id 4', 0, 0, 0), 
(5, '2015-01-11', '13:09', 56, 'Robyn Mills', '', 40, 21, 'Edit Member', 0, 0, 0), 
(6, '2015-01-12', '06:44', 56, 'Robyn Mills', '', 41, 56, 'Edit Setup for Demo Furnishings', 0, 0, 0), 
(7, '2015-08-16', '20:00', 55, 'John Smith', '', 41, 20, 'Edit Member', 0, 0, 0), 
(8, '2015-12-01', '06:54', 55, 'John Smith', '', 41, 18, 'Edit Member', 0, 0, 0);

-- # Tabel structure for table `boxes`
DROP TABLE  IF EXISTS `boxes`;
CREATE TABLE `boxes` (
  `box_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_office` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `from` mediumint(9) NOT NULL,
  `to` mediumint(9) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  `boxbag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `c_menu`
DROP TABLE  IF EXISTS `c_menu`;
CREATE TABLE `c_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `morder` smallint(4) NOT NULL,
  `level` tinyint(2) NOT NULL,
  `label` varchar(50) NOT NULL DEFAULT '',
  `onclick` text,
  `tooltip` varchar(250) NOT NULL DEFAULT '',
  `image_file` blob NOT NULL,
  `facility` char(2) NOT NULL DEFAULT '',
  `a1` char(1) NOT NULL DEFAULT 'N',
  `a2` char(1) NOT NULL DEFAULT 'N',
  `a3` char(1) NOT NULL DEFAULT 'N',
  `a4` char(1) NOT NULL DEFAULT 'N',
  `a5` char(1) NOT NULL DEFAULT 'N',
  `a6` char(1) NOT NULL DEFAULT 'N',
  `a7` char(1) NOT NULL DEFAULT 'N',
  `a8` char(1) NOT NULL DEFAULT 'N',
  `a9` char(1) NOT NULL DEFAULT 'N',
  `a10` char(1) NOT NULL DEFAULT 'N',
  `a11` char(1) NOT NULL DEFAULT 'N',
  `a12` char(1) NOT NULL DEFAULT 'N',
  `a13` char(1) NOT NULL DEFAULT 'N',
  `a14` char(1) NOT NULL DEFAULT 'N',
  `a15` char(1) NOT NULL DEFAULT 'N',
  `a16` char(1) NOT NULL DEFAULT 'N',
  `a17` char(1) NOT NULL DEFAULT 'N',
  `a18` char(1) NOT NULL DEFAULT 'N',
  `a19` char(1) NOT NULL DEFAULT 'N',
  `a20` char(1) NOT NULL DEFAULT 'Y',
  `std_sub` char(1) NOT NULL DEFAULT 'N',
  `extra_1` char(1) NOT NULL DEFAULT 'N',
  `extra_2` char(1) NOT NULL DEFAULT 'N',
  `extra_3` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `c_menu` (`menu_id`, `morder`, `level`, `label`, `onclick`, `tooltip`, `image_file`, `facility`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `a7`, `a8`, `a9`, `a10`, `a11`, `a12`, `a13`, `a14`, `a15`, `a16`, `a17`, `a18`, `a19`, `a20`, `std_sub`, `extra_1`, `extra_2`, `extra_3`) VALUES (1, 1, 0, 'Members', '', 'Clients Menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'N', 'N', 'Y'), 
(3, 3, 1, 'Administer Members', 'javascript:createTab(\'updtmembers.php\',\'Add/Edit/Delete Member Records\',0)', 'Add/Edit/Delete Member Records', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(5, 5, 0, 'Marketing', '', 'Marketing Functions', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'Y'), 
(6, 6, 1, 'Campaign Administration', '', 'Campaign Functions', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(7, 7, 2, 'Update Campaigns', 'javascript:createTab(\'updtcampaigns.php\',\'Update Campaign Data\',0)', 'Update Campaign Data', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(8, 8, 2, 'Run Campaign', 'javascript:createTab(\'runcampaign.php\',\'Run a Campaign\',0)', 'Run a Campaign', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(9, 9, 2, 'Update Outsource Providers', 'javascript:createTab(\'updtoutprov.php\',\'Add/Edit/Delete Outsoruce Providers\',0)', 'Add/Edit/Delete Outsoruce Providers', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(10, 10, 2, 'Campaign Statistics', '', 'Report on campaign statistics', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(11, 11, 3, 'By Campaign/Outsource', 'javascript:createTab(\'campstats.php\',\'Report on campaign statistics by campaign/outsource\',0)', 'Report on campaign statistics by campaign/outsource', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(12, 12, 2, 'Update Marketers', 'javascript:createTab(\'updtmarketers.php\',\'Add/Edit/Delete Marketers and their Staff\',0)', 'Add/Edit/Delete Marketers and their Staff', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'N', 'N', 'Y'), 
(13, 13, 0, 'Administrative Tools', '', 'Administrative Tools Menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(14, 14, 1, 'Update Workflow Stages', 'javascript:createTab(\'updtworkflow.php\',\'Update Workflow Stages\',0)', 'Update list of workflow stages', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(15, 15, 1, 'Duplicate Member Records', 'javascript:createTab(\'listduplicates.php\',\'List Duplicate member records\',0)', 'List Duplicate member records', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(16, 16, 1, 'Update Client Types', 'javascript:createTab(\'updtclienttypes.php\',\'Update Client Types\',0)', 'Update Client Types', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(17, 17, 1, 'Update Industries', 'javascript:createTab(\'updtindustries.php\',\'Update Industry Types\',0)', 'Update Industry Types', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(18, 18, 1, 'Update Accounting Categories', 'javascript:createTab(\'updtacccats.php\',\'Update Accounting Categories\',0)', 'Update Accounting Categories', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(19, 19, 0, 'Complaints Register', '', '', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(20, 20, 1, 'Administer Complaints', 'javascript:createTab(\'complaints.php\',\'List and update complaints\',0)', 'List and update complaints', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(21, 21, 0, 'Housekeeping', '', 'Housekeeping menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(22, 22, 1, 'Setup Company Details', 'javascript:createTab(\'../fin/hs_setup.php\',\'Setup Company Details\',0)', 'Setup Company Details', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(23, 23, 1, 'Update Users', 'javascript:createTab(\'hs_users.php\',\'Update users\',0)', 'Assign passwords to users and users to menu groups.', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(24, 24, 1, 'Update Menu Groups', 'javascript:createTab(\'hs_updtmeng.php\',\'Update Menu Groups\',0)', 'Assign menu options to groups of users.', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(25, 25, 1, 'Backup', 'javascript:createTab(\'../includes/bkup/backup.php\',\'Backup\',0)', 'Backup database for this company', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(26, 26, 1, 'Restore', 'javascript:createTab(\'../includes/bkup/rbkup.php\',\'Restore from Backup\',0)', 'Restore from backup', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', '');

-- # Tabel structure for table `campaign_costs`
DROP TABLE  IF EXISTS `campaign_costs`;
CREATE TABLE `campaign_costs` (
  `costs_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `item` varchar(70) NOT NULL,
  `cost` decimal(16,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`costs_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `campaign_docs`
DROP TABLE  IF EXISTS `campaign_docs`;
CREATE TABLE `campaign_docs` (
  `campdoc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date NOT NULL,
  `doc` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`campdoc_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `campaigns`
DROP TABLE  IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `campaign_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(45) NOT NULL,
  `startdate` date NOT NULL DEFAULT '0000-00-00',
  `staff` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `goals` text NOT NULL,
  `outprov_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`campaign_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `candidates`
DROP TABLE  IF EXISTS `candidates`;
CREATE TABLE `candidates` (
  `candidate_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `cand_status` char(1) NOT NULL DEFAULT 'A',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `lastname` varchar(45) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `preferred` varchar(50) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `workflow` varchar(45) NOT NULL,
  `candstatus` varchar(10) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`candidate_id`),
  KEY `sub_id` (`sub_id`),
  KEY `member_id` (`member_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `client_company_xref`
DROP TABLE  IF EXISTS `client_company_xref`;
CREATE TABLE `client_company_xref` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL DEFAULT '0',
  `company_id` int(10) unsigned NOT NULL DEFAULT '0',
  `drno` int(10) unsigned NOT NULL DEFAULT '0',
  `crno` int(10) unsigned NOT NULL DEFAULT '0',
  `drsub` int(2) NOT NULL DEFAULT '0',
  `crsub` int(2) NOT NULL DEFAULT '0',
  `subname` varchar(45) NOT NULL DEFAULT '',
  `hs_contractor` int(11) NOT NULL DEFAULT '0',
  `blocked` char(3) NOT NULL DEFAULT 'No',
  `sortcode` varchar(45) NOT NULL DEFAULT '',
  `current` double(16,2) NOT NULL DEFAULT '0.00',
  `d30` double(16,2) NOT NULL DEFAULT '0.00',
  `d60` double(16,2) NOT NULL DEFAULT '0.00',
  `d90` double(16,2) NOT NULL DEFAULT '0.00',
  `d120` double(16,2) NOT NULL DEFAULT '0.00',
  `tcur` double(16,2) NOT NULL DEFAULT '0.00',
  `t30` double(16,2) NOT NULL DEFAULT '0.00',
  `t60` double(16,2) NOT NULL DEFAULT '0.00',
  `t90` double(16,2) NOT NULL DEFAULT '0.00',
  `t120` double(16,2) NOT NULL DEFAULT '0.00',
  `limit` int(4) NOT NULL,
  `monlimit` double(16,2) NOT NULL DEFAULT '0.00',
  `sellprice` int(4) NOT NULL,
  `priceband` int(11) NOT NULL DEFAULT '1',
  `sendstatement` char(5) NOT NULL DEFAULT 'Post',
  `billing` int(11) NOT NULL DEFAULT '0',
  `email` int(11) NOT NULL DEFAULT '0',
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `member` varchar(75) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `client_company_xref` (`uid`, `client_id`, `company_id`, `drno`, `crno`, `drsub`, `crsub`, `subname`, `hs_contractor`, `blocked`, `sortcode`, `current`, `d30`, `d60`, `d90`, `d120`, `tcur`, `t30`, `t60`, `t90`, `t120`, `limit`, `monlimit`, `sellprice`, `priceband`, `sendstatement`, `billing`, `email`, `lastupdated`, `member`) VALUES (22, 18, 21, 30000018, 0, 0, 0, '', 0, 'No', 'Bloggs30000018-0', 577.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2015-12-01 09:29:00', 'Bloggs'), 
(23, 20, 21, 0, 20000020, 0, 0, '', 0, 'No', 'Dannys20000020-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2015-01-11 14:07:44', 'Dannys'), 
(24, 19, 21, 0, 20000019, 0, 0, '', 0, 'No', 'M Office solutions20000019-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2015-01-11 14:07:50', 'M Office solutions'), 
(25, 21, 21, 0, 20000021, 0, 0, '', 0, 'No', 'Sealy Matresses20000021-0', -1210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2015-12-01 09:31:06', 'Sealy Matresses');

-- # Tabel structure for table `client_types`
DROP TABLE  IF EXISTS `client_types`;
CREATE TABLE `client_types` (
  `client_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_type` varchar(15) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`client_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `client_types` (`client_type_id`, `client_type`, `sub_id`) VALUES (1, 'Sales', 40), 
(2, 'Services', 40), 
(3, 'Sales/Services', 40), 
(4, 'Training', 40), 
(5, 'Tenants', 40);

-- # Tabel structure for table `clienttype_xref`
DROP TABLE  IF EXISTS `clienttype_xref`;
CREATE TABLE `clienttype_xref` (
  `clienttype_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `client_type` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`clienttype_xref_id`),
  KEY `member_id` (`member_id`,`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `clienttype_xref` (`clienttype_xref_id`, `member_id`, `client_type`, `sub_id`) VALUES (1, 8, 'Sales/Services', 40);

-- # Tabel structure for table `comms`
DROP TABLE  IF EXISTS `comms`;
CREATE TABLE `comms` (
  `comms_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `comms_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `country_code` varchar(4) NOT NULL,
  `area_code` varchar(4) NOT NULL DEFAULT ' ',
  `comm` varchar(75) NOT NULL DEFAULT ' ',
  `comm2` varchar(75) NOT NULL,
  `preferred` char(1) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `billing` char(1) NOT NULL DEFAULT 'N',
  `delivery` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`comms_id`),
  KEY `member_id` (`member_id`),
  KEY `comm2` (`comm2`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `comms` (`comms_id`, `member_id`, `staff_id`, `comms_type_id`, `country_code`, `area_code`, `comm`, `comm2`, `preferred`, `sub_id`, `billing`, `delivery`) VALUES (18, 18, 0, 2, 61, 9, 1234555, 1234555, '', 0, 'N', 'N'), 
(19, 19, 0, 2, 61, 7, 99898, 99898, '', 0, 'N', 'N'), 
(20, 20, 0, 2, 61, 7, 90807, 90807, '', 0, 'N', 'N'), 
(21, 21, 0, 2, 61, 7, 66998, 66998, '', 0, 'N', 'N');

-- # Tabel structure for table `comms_type`
DROP TABLE  IF EXISTS `comms_type`;
CREATE TABLE `comms_type` (
  `comms_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comm_type` varchar(45) NOT NULL,
  PRIMARY KEY (`comms_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `comms_type` (`comms_type_id`, `comm_type`) VALUES (1, 'Phone Home'), 
(2, 'Phone Work'), 
(3, 'Mobile'), 
(4, 'Email'), 
(5, 'Skype'), 
(6, 'Fax Work'), 
(7, 'Fax Home'), 
(8, 'After Hours'), 
(9, 'Facebook'), 
(10, 'Twitter'), 
(11, 'Web');

-- # Tabel structure for table `companies`
DROP TABLE  IF EXISTS `companies`;
CREATE TABLE `companies` (
  `company_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) NOT NULL,
  `db_name` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `business_number` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `complaint_nature`
DROP TABLE  IF EXISTS `complaint_nature`;
CREATE TABLE `complaint_nature` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `nature` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `complaint_nature` (`uid`, `nature`) VALUES (1, 'Customer Service'), 
(2, 'Faulty Item');

-- # Tabel structure for table `complaints`
DROP TABLE  IF EXISTS `complaints`;
CREATE TABLE `complaints` (
  `complaint_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `complainant` varchar(50) NOT NULL,
  `against` varchar(50) NOT NULL,
  `received` date NOT NULL DEFAULT '0000-00-00',
  `via` varchar(20) NOT NULL,
  `acknowledged` date NOT NULL DEFAULT '0000-00-00',
  `closed` date NOT NULL DEFAULT '0000-00-00',
  `compensation` decimal(16,2) NOT NULL DEFAULT '0.00',
  `medium` varchar(50) NOT NULL,
  `source` varchar(50) NOT NULL,
  `nature` varchar(50) NOT NULL,
  `product` varchar(100) NOT NULL,
  `taken_by` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `outcome` text NOT NULL,
  `notes` text NOT NULL,
  `responded` date NOT NULL DEFAULT '0000-00-00',
  `cause` varchar(100) NOT NULL,
  `further_action` text NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `documents`
DROP TABLE  IF EXISTS `documents`;
CREATE TABLE `documents` (
  `doc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date NOT NULL,
  `doc` varchar(100) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`doc_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `emails`
DROP TABLE  IF EXISTS `emails`;
CREATE TABLE `emails` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `email_date` date NOT NULL DEFAULT '0000-00-00',
  `email_from` varchar(45) NOT NULL,
  `email_subject` varchar(45) NOT NULL,
  `email_message` text NOT NULL,
  `email_time` char(8) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `emails2send`
DROP TABLE  IF EXISTS `emails2send`;
CREATE TABLE `emails2send` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email_date` date NOT NULL DEFAULT '0000-00-00',
  `email_from` varchar(70) NOT NULL,
  `email_to` varchar(70) NOT NULL,
  `cc` varchar(300) NOT NULL,
  `email_subject` varchar(70) NOT NULL,
  `email_message` text NOT NULL,
  `sent` char(1) NOT NULL DEFAULT 'N',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `email_date` (`email_date`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `industries`
DROP TABLE  IF EXISTS `industries`;
CREATE TABLE `industries` (
  `industry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `industry` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`industry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `industries` (`industry_id`, `industry`, `sub_id`) VALUES (1, 'Technical', 40), 
(2, 'Training', 40), 
(3, 'Wholesale', 40);

-- # Tabel structure for table `links`
DROP TABLE  IF EXISTS `links`;
CREATE TABLE `links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `members`
DROP TABLE  IF EXISTS `members`;
CREATE TABLE `members` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alt_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(45) NOT NULL DEFAULT '',
  `middlename` varchar(45) NOT NULL,
  `preferredname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL DEFAULT '',
  `dob` date NOT NULL,
  `gender` char(6) NOT NULL,
  `title` char(9) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `client_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `age` smallint(3) unsigned NOT NULL,
  `checked` char(3) NOT NULL DEFAULT 'No',
  `occupation` varchar(45) NOT NULL,
  `industry_id` int(11) NOT NULL,
  `position` varchar(45) NOT NULL,
  `dependant` char(1) NOT NULL DEFAULT 'N',
  `staff` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `next_meeting` date NOT NULL DEFAULT '0000-00-00',
  `client_type` varchar(20) NOT NULL,
  PRIMARY KEY (`member_id`),
  KEY `lastname` (`lastname`),
  KEY `dob` (`dob`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `members` (`member_id`, `alt_id`, `firstname`, `middlename`, `preferredname`, `lastname`, `dob`, `gender`, `title`, `sub_id`, `client_type_id`, `age`, `checked`, `occupation`, `industry_id`, `position`, `dependant`, `staff`, `status`, `next_meeting`, `client_type`) VALUES (18, 0, 'Joe', '', '', 'Bloggs', '1964-02-02', 'Male', 'Mr', 41, 0, 50, 'No', 'Retired', 0, '', 'N', 0, '', '0000-00-00', ''), 
(19, 0, '', '', '', 'M Office solutions', '0000-00-00', 'Male', 'Mr', 41, 0, 0, 'No', 'Wholesaler', 0, '', 'N', 0, '', '0000-00-00', ''), 
(20, 0, '', '', '', 'Dannys', '0000-00-00', 'Male', 'Mr', 41, 0, 0, 'No', 'Wholesaler', 0, '', 'N', 0, '', '0000-00-00', ''), 
(21, 0, '', '', '', 'Sealy Mattresses', '0000-00-00', 'Male', 'Mr', 41, 0, 2015, 'No', 'Wholesaler', 0, '', 'N', 'Robyn Mills', ' ', '0000-00-00', ' ');

-- # Tabel structure for table `outprovs`
DROP TABLE  IF EXISTS `outprovs`;
CREATE TABLE `outprovs` (
  `outprov_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `phone` varchar(30) NOT NULL,
  `address` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `web` varchar(70) NOT NULL,
  PRIMARY KEY (`outprov_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `quotelines`
DROP TABLE  IF EXISTS `quotelines`;
CREATE TABLE `quotelines` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL DEFAULT '0',
  `itemcode` varchar(30) NOT NULL,
  `quantity` decimal(9,3) NOT NULL DEFAULT '0.000',
  `price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `taxtype` char(3) NOT NULL DEFAULT '',
  `taxpcent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(16,2) NOT NULL DEFAULT '0.00',
  `taxindex` int(11) NOT NULL,
  `disc_type` char(1) NOT NULL DEFAULT '',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `ref_no` char(15) NOT NULL,
  `item` varchar(45) NOT NULL DEFAULT '',
  `unit` char(4) NOT NULL DEFAULT '',
  `value` decimal(16,2) NOT NULL DEFAULT '0.00',
  `supplier` int(11) NOT NULL DEFAULT '0',
  `currency` char(3) NOT NULL DEFAULT '',
  `sub` int(11) NOT NULL DEFAULT '0',
  `consign` char(1) NOT NULL DEFAULT '',
  `rate` decimal(7,3) NOT NULL DEFAULT '0.000',
  `grnlineno` int(11) NOT NULL,
  `paid` decimal(16,2) NOT NULL DEFAULT '0.00',
  `note` text NOT NULL,
  `sent` decimal(16,2) NOT NULL DEFAULT '0.00',
  `dn` varchar(15) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `quotes`
DROP TABLE  IF EXISTS `quotes`;
CREATE TABLE `quotes` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `coy_id` int(11) NOT NULL DEFAULT '0',
  `accountno` int(11) NOT NULL DEFAULT '0',
  `branch` char(4) NOT NULL DEFAULT '',
  `sub` int(11) NOT NULL DEFAULT '0',
  `gldesc` char(40) NOT NULL DEFAULT '',
  `invno` int(11) NOT NULL DEFAULT '0',
  `ref_no` char(15) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `totvalue` double(16,2) NOT NULL DEFAULT '0.00',
  `tax` double(16,2) NOT NULL DEFAULT '0.00',
  `cash` double(16,2) NOT NULL DEFAULT '0.00',
  `cheque` double(16,2) NOT NULL DEFAULT '0.00',
  `eftpos` double(16,2) NOT NULL DEFAULT '0.00',
  `ccard` double(16,2) NOT NULL DEFAULT '0.00',
  `staff` varchar(45) NOT NULL,
  `xref` char(15) NOT NULL DEFAULT '',
  `postaladdress` varchar(100) NOT NULL,
  `deliveryaddress` varchar(100) NOT NULL,
  `client` varchar(80) NOT NULL,
  `note` text NOT NULL,
  `coyname` varchar(50) NOT NULL,
  `invref` varchar(15) NOT NULL,
  `currency` char(3) NOT NULL,
  `rate` decimal(7,3) NOT NULL DEFAULT '1.000',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referrals`
DROP TABLE  IF EXISTS `referrals`;
CREATE TABLE `referrals` (
  `referral_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(10) DEFAULT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `middlename` varchar(45) DEFAULT NULL,
  `preferred` varchar(45) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `commtype` int(11) NOT NULL DEFAULT '0',
  `country` varchar(45) DEFAULT NULL,
  `area` varchar(10) DEFAULT NULL,
  `comm` varchar(80) DEFAULT NULL,
  `commtype2` int(11) NOT NULL,
  `country2` varchar(45) DEFAULT NULL,
  `area2` varchar(10) DEFAULT NULL,
  `comm2` varchar(80) DEFAULT NULL,
  `location` varchar(20) DEFAULT NULL,
  `addresstype` int(11) NOT NULL DEFAULT '0',
  `streetno` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `suburb` varchar(50) DEFAULT NULL,
  `town` varchar(50) DEFAULT NULL,
  `postcode` varchar(6) DEFAULT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date DEFAULT NULL,
  `referred_id` int(11) NOT NULL DEFAULT '0',
  `phoned` char(3) NOT NULL DEFAULT 'No',
  `phcounted` char(1) NOT NULL DEFAULT 'N',
  `note` text NOT NULL,
  PRIMARY KEY (`referral_id`),
  KEY `lastname` (`lastname`),
  KEY `comm` (`comm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referrals_phone`
DROP TABLE  IF EXISTS `referrals_phone`;
CREATE TABLE `referrals_phone` (
  `ref_phone_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL,
  `ttime` char(11) NOT NULL,
  `referral_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ref_phone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referred`
DROP TABLE  IF EXISTS `referred`;
CREATE TABLE `referred` (
  `referred_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referred` varchar(25) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`referred_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `rural`
DROP TABLE  IF EXISTS `rural`;
CREATE TABLE `rural` (
  `rural_id` int(11) NOT NULL AUTO_INCREMENT,
  `rd` mediumint(9) NOT NULL,
  `town` varchar(100) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  PRIMARY KEY (`rural_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `sayings`
DROP TABLE  IF EXISTS `sayings`;
CREATE TABLE `sayings` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `heading` varchar(45) NOT NULL,
  `saying` varchar(400) NOT NULL,
  `credit` varchar(45) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `status`
DROP TABLE  IF EXISTS `status`;
CREATE TABLE `status` (
  `status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `status` (`status_id`, `status`, `sub_id`) VALUES (1, 'Lead', 40), 
(2, 'Prospect', 40), 
(3, 'Client', 40), 
(4, 'Supplier', 40);

-- # Tabel structure for table `streets`
DROP TABLE  IF EXISTS `streets`;
CREATE TABLE `streets` (
  `street_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `street` varchar(45) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `area` varchar(45) NOT NULL,
  `postcode` varchar(4) NOT NULL,
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `subemails`
DROP TABLE  IF EXISTS `subemails`;
CREATE TABLE `subemails` (
  `subemail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(70) NOT NULL,
  `recipient` varchar(70) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`subemail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `tmp44_assocfile`
DROP TABLE  IF EXISTS `tmp44_assocfile`;
CREATE TABLE `tmp44_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tmp44_assocfile` (`associd`, `mid`, `assoc`, `ofid`, `ofname`) VALUES (1, 4, 'Employee', 5, ' Itron'), 
(2, 4, 'Spouse', 7, 'Danielle Dickinson'), 
(3, 4, 'Child', 3, 'Ivan Kostrencic');

-- # Tabel structure for table `tmp55_assocfile`
DROP TABLE  IF EXISTS `tmp55_assocfile`;
CREATE TABLE `tmp55_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `tmp56_assocfile`
DROP TABLE  IF EXISTS `tmp56_assocfile`;
CREATE TABLE `tmp56_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `todo`
DROP TABLE  IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enter_date` date NOT NULL,
  `enter_staff` varchar(45) NOT NULL,
  `todo_by` varchar(45) NOT NULL,
  `complete_by` date NOT NULL,
  `task` varchar(250) NOT NULL,
  `done` char(3) NOT NULL DEFAULT 'No',
  `category` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`todo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `todo` (`todo_id`, `enter_date`, `enter_staff`, `todo_by`, `complete_by`, `task`, `done`, `category`, `sub_id`) VALUES (1, '2015-02-15', 'John Smith', 'John Smith', '2015-02-20', 'To check stock numbers', 'No', 'Standard', 41);

-- # Tabel structure for table `workflow`
DROP TABLE  IF EXISTS `workflow`;
CREATE TABLE `workflow` (
  `process_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `process` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `porder` int(10) NOT NULL DEFAULT '0',
  `aide_memoir` text NOT NULL,
  PRIMARY KEY (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `workflow_xref`
DROP TABLE  IF EXISTS `workflow_xref`;
CREATE TABLE `workflow_xref` (
  `workflow_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `process` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`workflow_xref_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`),
  KEY `process` (`process`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp44_campfile`
DROP TABLE  IF EXISTS `ztmp44_campfile`;
CREATE TABLE `ztmp44_campfile` (
  `campaign_id` int(11) DEFAULT '0',
  `name` varchar(45) DEFAULT '',
  `startdate` date DEFAULT NULL,
  `staff` varchar(45) DEFAULT '',
  `description` text,
  `goals` text,
  `complete` decimal(5,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp44_tasks`
DROP TABLE  IF EXISTS `ztmp44_tasks`;
CREATE TABLE `ztmp44_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp46_tasks`
DROP TABLE  IF EXISTS `ztmp46_tasks`;
CREATE TABLE `ztmp46_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp55_assocfile`
DROP TABLE  IF EXISTS `ztmp55_assocfile`;
CREATE TABLE `ztmp55_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp55_campfile`
DROP TABLE  IF EXISTS `ztmp55_campfile`;
CREATE TABLE `ztmp55_campfile` (
  `campaign_id` int(11) DEFAULT '0',
  `name` varchar(45) DEFAULT '',
  `startdate` date DEFAULT NULL,
  `staff` varchar(45) DEFAULT '',
  `description` text,
  `goals` text,
  `complete` decimal(5,2) DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp55_tasks`
DROP TABLE  IF EXISTS `ztmp55_tasks`;
CREATE TABLE `ztmp55_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `ztmp55_tasks` (`todo_id`, `complete_by`, `task`) VALUES (1, '2015-02-20', 'To check stock numbers');

-- # Tabel structure for table `ztmp56_tasks`
DROP TABLE  IF EXISTS `ztmp56_tasks`;
CREATE TABLE `ztmp56_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1; 
COMMIT; 
SET AUTOCOMMIT = 1; 
