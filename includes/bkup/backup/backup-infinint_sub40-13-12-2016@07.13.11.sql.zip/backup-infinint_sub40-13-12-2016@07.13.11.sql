-- # A Mysql Backup System
-- # Export created: 2016/12/13 on 07:13
-- # Database : infinint_sub40
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `acats`
DROP TABLE  IF EXISTS `acats`;
CREATE TABLE `acats` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `category` varchar(40) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `acats` (`uid`, `member_id`, `category`) VALUES (1, 8, 'D/D'), 
(2, 5, 'D/D');

-- # Tabel structure for table `acccats`
DROP TABLE  IF EXISTS `acccats`;
CREATE TABLE `acccats` (
  `acccat_id` int(11) NOT NULL AUTO_INCREMENT,
  `acccat` varchar(30) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`acccat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `acccats` (`acccat_id`, `acccat`, `sub_id`) VALUES (1, 'D/D', 0);

-- # Tabel structure for table `access`
DROP TABLE  IF EXISTS `access`;
CREATE TABLE `access` (
  `access_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `module` char(3) NOT NULL,
  `usergroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `activities`
DROP TABLE  IF EXISTS `activities`;
CREATE TABLE `activities` (
  `activities_id` int(11) NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `ttime` char(10) NOT NULL,
  `activity` text NOT NULL,
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(25) NOT NULL,
  `contact` varchar(30) NOT NULL DEFAULT 'Other',
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`activities_id`),
  KEY `staff_id` (`staff_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`),
  FULLTEXT KEY `activity` (`activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- # Tabel structure for table `activity_status`
DROP TABLE  IF EXISTS `activity_status`;
CREATE TABLE `activity_status` (
  `activity_status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity_status` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`activity_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `address_type`
DROP TABLE  IF EXISTS `address_type`;
CREATE TABLE `address_type` (
  `address_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address_type` varchar(45) NOT NULL,
  PRIMARY KEY (`address_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `address_type` (`address_type_id`, `address_type`) VALUES (1, 'Home'), 
(2, 'Work');

-- # Tabel structure for table `addresses`
DROP TABLE  IF EXISTS `addresses`;
CREATE TABLE `addresses` (
  `address_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `staff_id` int(10) unsigned NOT NULL,
  `location` varchar(15) NOT NULL,
  `address_type_id` int(10) unsigned NOT NULL,
  `street_no` varchar(45) NOT NULL,
  `ad1` varchar(45) NOT NULL DEFAULT '',
  `ad2` varchar(45) NOT NULL DEFAULT '',
  `suburb` varchar(45) NOT NULL DEFAULT '',
  `town` varchar(45) NOT NULL DEFAULT '',
  `state` varchar(45) NOT NULL DEFAULT '',
  `country` varchar(45) NOT NULL DEFAULT '',
  `postcode` varchar(15) NOT NULL DEFAULT '',
  `preferredp` char(1) NOT NULL DEFAULT 'N',
  `preferredv` char(1) NOT NULL DEFAULT 'N',
  `sub_id` int(11) NOT NULL,
  `billing` char(1) NOT NULL DEFAULT 'N',
  `delivery` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`address_id`),
  KEY `member_id` (`member_id`),
  KEY `suburb` (`suburb`),
  KEY `town` (`town`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `addresses` (`address_id`, `member_id`, `staff_id`, `location`, `address_type_id`, `street_no`, `ad1`, `ad2`, `suburb`, `town`, `state`, `country`, `postcode`, `preferredp`, `preferredv`, `sub_id`, `billing`, `delivery`) VALUES (2, 3, 0, 'Street', 2, '4 ', 'Wilkins Close', '', 'Highlands', 'Maroochydore', '', '', 4558, 'N', 'N', 0, 'N', 'N'), 
(3, 4, 0, 'Street', 1, '1/79', 'Rosedale Road', '', 'Albany', 'Brisbane', '', '', 4069, '', '', 0, 'N', 'N'), 
(5, 7, 0, 'Street', 2, 34, 'Steve Irwin Way', '', 'Swansea', 'Brisbane', '', '', 4001, 'N', 'N', 0, 'N', 'N'), 
(6, 8, 0, 'Street', 2, 'The Plaza', 'Sunshine Street', '', 'Cbd', 'Maroochydore', '', '', 4558, 'N', 'N', 0, 'N', 'N'), 
(7, 9, 0, 'Street', 2, 1, 'Homemaker Centre', '', 'Maroochydore', 'Qld', '', '', 4558, '', '', 0, 'N', 'N'), 
(8, 10, 0, 'Street', 2, 2, 'Homemaker Centre', '', 'Maroochydore', 'Qld', '', '', 4558, '', '', 0, 'N', 'N'), 
(9, 4, 0, 'Street', 2, 45, 'Main road', '', 'Rosedale', 'Brisbane', '', '', '', 'N', 'N', 0, 'N', 'N'), 
(10, 5, 0, 'Post Box', 2, 'GPO Box 48', '', 'Albany', '', 'Auckland', '', '', '', 'Y', 'N', 0, 'N', 'N'), 
(11, 11, 0, 'Street', 2, 'Homemaker Centre', 'Maroochy Road', '', '', 'Maroochydore', '', '', '', 'N', 'N', 0, 'N', 'N'), 
(12, 12, 0, 'Street', 2, '1 Rezende Street', '', '', '', 'Maroochydore', '', '', '', '', '', 0, 'N', 'N'), 
(13, 13, 0, 'Street', 2, 1, 'Satellite Towers', '', 'Buderim', 'Maroochydore', '', '', 4559, 'Y', 'N', 0, 'N', 'N'), 
(14, 15, 0, 'Street', 2, 1, 'Turner Street', '', '', 'Maroochydore', '', '', 4558, '', '', 0, 'N', 'N'), 
(15, 14, 0, 'Street', 2, 15, 'Ladi Street', '', 'Buderim', 'Maroochydore', '', 'Aus', 4558, 'N', 'N', 0, 'N', 'N'), 
(16, 16, 0, 'Street', 2, 5, 'Hilly Orchard', '', 'Ebley', 'Maroochydore', '', '', 4558, 'N', 'N', 0, 'N', 'N'), 
(17, 17, 0, 'Street', 2, 2, 'Williams Street', '', 'Buderim', 'Maroochydore', '', 'Aus', 4560, 'N', 'N', 0, 'N', 'N'), 
(18, 18, 0, 'Street', 2, 21, 'Beach Road', '', 'Maroochydore', 'Qld', '', '', '', 'N', 'N', 0, 'N', 'N'), 
(19, 19, 0, 'Street', 2, 1, 'St Martins Tc', '', 'Buderim', 'Maroochydore', '', '', 4559, '', '', 0, 'N', 'N'), 
(20, 21, 0, 'Street', 2, 'The Fieldings', 'Slad', '', 'Gloucestershire', 'Gl6 7qd', '', 'UK', 'GL', 'N', 'N', 0, 'Y', 'N'), 
(21, 6, 0, 'Street', 0, 114, 'Cainscross Road', '', 'Stroud', 'Gl5 4hn', '', '', 'GL5', 'N', 'N', 0, 'N', 'N'), 
(22, 6, 0, 'Street', 0, '', '', '', '', 'Stroud', '', '', '', 'N', 'N', 0, 'Y', 'N');

-- # Tabel structure for table `assoc_xref`
DROP TABLE  IF EXISTS `assoc_xref`;
CREATE TABLE `assoc_xref` (
  `assoc_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `association` varchar(30) NOT NULL,
  `of_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `dependant` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`assoc_xref_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `assoc_xref` (`assoc_xref_id`, `member_id`, `association`, `of_id`, `sub_id`, `dependant`) VALUES (1, 4, 'Employee', 5, 0, 'N'), 
(2, 5, 'Employer', 4, 0, 'N'), 
(3, 7, 'Spouse', 4, 0, 'N'), 
(4, 4, 'Spouse', 7, 0, 'N'), 
(5, 4, 'Child', 3, 0, 'N'), 
(6, 3, 'Parent', 4, 0, 'N');

-- # Tabel structure for table `attachments`
DROP TABLE  IF EXISTS `attachments`;
CREATE TABLE `attachments` (
  `doc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL,
  `doc` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `audit`
DROP TABLE  IF EXISTS `audit`;
CREATE TABLE `audit` (
  `audit_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `ttime` char(5) NOT NULL DEFAULT '00:00',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(45) NOT NULL,
  `userip` varchar(30) NOT NULL,
  `sub_id` tinyint(4) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(70) NOT NULL,
  `address_id` int(11) NOT NULL DEFAULT '0',
  `comms_id` int(11) NOT NULL DEFAULT '0',
  `activities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`audit_id`),
  KEY `ddate` (`ddate`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8;

INSERT INTO `audit` (`audit_id`, `ddate`, `ttime`, `user_id`, `uname`, `userip`, `sub_id`, `member_id`, `action`, `address_id`, `comms_id`, `activities_id`) VALUES (4, '2014-10-11', '16:04', 44, 'Robyn Mills', '', 0, 2, 'Added member id 2', 0, 0, 0), 
(5, '2014-10-11', '16:08', 44, 'Robyn Mills', '', 0, 3, 'Added member id 3', 0, 0, 0), 
(6, '2014-10-11', '13:12', 44, 'Robyn Mills', '', 40, 5, 'Edit Member', 0, 0, 0), 
(7, '2014-10-11', '16:16', 44, 'Robyn Mills', '', 0, 4, 'Added member id 4', 0, 0, 0), 
(8, '2014-10-11', '16:19', 44, 'Robyn Mills', '', 0, 5, 'Added member id 5', 0, 0, 0), 
(9, '2014-10-11', '16:24', 44, 'Robyn Mills', '', 0, 6, 'Added member id 6', 0, 0, 0), 
(10, '2014-10-11', '16:35', 44, 'Robyn Mills', '', 0, 7, 'Added member id 7', 0, 0, 0), 
(11, '2014-10-11', '16:45', 44, 'Robyn Mills', '', 0, 8, 'Added member id 8', 0, 0, 0), 
(12, '2014-10-11', '14:30', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(13, '2014-10-11', '14:34', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(14, '2014-10-11', '14:37', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(15, '2014-10-11', '14:43', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(16, '2014-10-11', '15:55', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(17, '2014-10-11', '15:56', 44, 'Robyn Mills', '', 40, 9, 'Edit Member', 0, 0, 0), 
(18, '2014-10-12', '10:12', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(19, '2014-10-12', '10:13', 44, 'Robyn Mills', '', 40, 5, 'Edit Member', 0, 0, 0), 
(20, '2014-10-12', '10:16', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(21, '2014-10-12', '10:20', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(22, '2014-10-12', '10:23', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(23, '2014-10-12', '10:24', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(24, '2014-10-12', '10:24', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(25, '2014-10-12', '12:11', 44, 'Robyn Mills', '', 0, 4, 'Add Address', 9, 0, 0), 
(26, '2014-10-12', '12:13', 44, 'Robyn Mills', '', 0, 8, 'Edit Address', 6, 0, 0), 
(27, '2014-10-12', '12:17', 44, 'Robyn Mills', '', 0, 4, 'Edit Communication', 0, 4, 0), 
(28, '2014-10-12', '13:06', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(29, '2014-10-12', '13:07', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(30, '2014-10-12', '13:09', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(31, '2014-10-12', '13:13', 44, 'Robyn Mills', '', 0, 7, 'Edit Address', 5, 0, 0), 
(32, '2014-10-12', '13:14', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(33, '2014-10-12', '13:16', 44, 'Robyn Mills', '', 40, 5, 'Edit Member', 0, 0, 0), 
(34, '2014-10-12', '13:16', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(35, '2014-10-12', '13:17', 44, 'Robyn Mills', '', 40, 9, 'Edit Member', 0, 0, 0), 
(36, '2014-10-12', '13:17', 44, 'Robyn Mills', '', 40, 9, 'Edit Member', 0, 0, 0), 
(37, '2014-10-12', '13:17', 44, 'Robyn Mills', '', 40, 10, 'Edit Member', 0, 0, 0), 
(38, '2014-10-12', '13:18', 44, 'Robyn Mills', '', 40, 10, 'Edit Member', 0, 0, 0), 
(39, '2014-10-12', '13:19', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(40, '2014-10-12', '13:19', 44, 'Robyn Mills', '', 40, 3, 'Edit Member', 0, 0, 0), 
(41, '2014-10-19', '17:37', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(42, '2014-10-25', '12:19', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(43, '2014-10-27', '17:53', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(44, '2014-10-27', '17:53', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(45, '2014-10-27', '17:57', 44, 'Robyn Mills', '', 40, 5, 'Edit Member', 0, 0, 0), 
(46, '2014-10-27', '18:04', 44, 'Robyn Mills', '', 0, 3, 'Edit Address', 2, 0, 0), 
(47, '2014-10-27', '18:04', 44, 'Robyn Mills', '', 0, 6, 'Edit Address', 4, 0, 0), 
(48, '2014-10-27', '18:08', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(49, '2014-10-29', '19:32', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(50, '2014-10-29', '19:32', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(51, '2014-10-29', '19:37', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(52, '2014-11-01', '09:47', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(53, '2014-11-03', '12:45', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Murray Russell', 0, 0, 0), 
(54, '2014-11-03', '12:47', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robray Ltd', 0, 0, 0), 
(55, '2014-11-03', '12:47', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robray Ltd', 0, 0, 0), 
(56, '2014-11-03', '12:48', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(57, '2014-11-03', '12:49', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(58, '2014-11-03', '16:53', 44, 'Robyn Mills', '', 0, 11, 'Added member id 11', 0, 0, 0), 
(59, '2014-11-03', '17:02', 44, 'Robyn Mills', '', 0, 11, 'Edit Address', 11, 0, 0), 
(60, '2014-11-20', '14:56', 44, 'Robyn Mills', '', 40, 11, 'Edit Member', 0, 0, 0), 
(61, '2014-11-20', '14:57', 44, 'Robyn Mills', '', 40, 11, 'Edit Member', 0, 0, 0), 
(62, '2014-11-21', '09:21', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(63, '2014-11-21', '09:22', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(64, '2014-11-22', '17:58', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(65, '2014-11-22', '21:45', 44, 'Robyn Mills', '', 0, 12, 'Added member id 12', 0, 0, 0), 
(66, '2014-11-23', '11:49', 44, 'Robyn Mills', '', 0, 13, 'Added member id 13', 0, 0, 0), 
(67, '2014-11-23', '13:48', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(68, '2014-11-26', '10:01', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(69, '2014-11-26', '10:01', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(70, '2014-12-05', '09:02', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(71, '2014-12-10', '09:57', 44, 'Robyn Mills', '', 0, 14, 'Added member id 14', 0, 0, 0), 
(72, '2014-12-10', '07:48', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(73, '2014-12-10', '07:48', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(74, '2014-12-10', '07:49', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(75, '2014-12-10', '19:25', 44, 'Robyn Mills', '', 0, 14, 'Add Address', 15, 0, 0), 
(76, '2014-12-10', '19:26', 44, 'Robyn Mills', '', 40, 14, 'Edit Member', 0, 0, 0), 
(77, '2014-12-10', '19:27', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(78, '2014-12-10', '19:34', 44, 'Robyn Mills', '', 0, 14, 'Edit Address', 15, 0, 0), 
(79, '2014-12-10', '19:35', 44, 'Robyn Mills', '', 40, 14, 'Edit Member', 0, 0, 0), 
(80, '2014-12-13', '09:24', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(81, '2014-12-14', '15:35', 44, 'Robyn Mills', '', 0, 16, 'Added member id 16', 0, 0, 0), 
(82, '2014-12-14', '12:38', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(83, '2014-12-14', '12:39', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(84, '2014-12-24', '17:10', 44, 'Robyn Mills', '', 0, 4, 'Edit Address', 9, 0, 0), 
(85, '2014-12-24', '17:10', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(86, '2014-12-24', '17:27', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(87, '2015-01-04', '10:42', 44, 'Robyn Mills', '', 0, 16, 'Edit Address', 16, 0, 0), 
(88, '2015-01-04', '10:44', 44, 'Robyn Mills', '', 40, 17, 'Add Member', 0, 0, 0), 
(89, '2015-01-04', '10:45', 44, 'Robyn Mills', '', 0, 17, 'Add Communication', 0, 17, 0), 
(90, '2015-01-04', '10:46', 44, 'Robyn Mills', '', 0, 17, 'Add Address', 17, 0, 0), 
(91, '2015-01-04', '10:48', 44, 'Robyn Mills', '', 40, 17, 'Edit Member', 0, 0, 0), 
(92, '2015-01-10', '09:28', 44, 'Robyn Mills', '', 40, 17, 'Edit Member', 0, 0, 0), 
(93, '2015-01-10', '11:22', 44, 'Robyn Mills', '', 40, 17, 'Edit Member', 0, 0, 0), 
(94, '2015-01-10', '11:23', 44, 'Robyn Mills', '', 40, 14, 'Edit Member', 0, 0, 0), 
(95, '2015-01-11', '10:24', 44, 'Robyn Mills', '', 0, 18, 'Added member id 18', 0, 0, 0), 
(96, '2015-01-11', '07:25', 44, 'Robyn Mills', '', 40, 18, 'Edit Member', 0, 0, 0), 
(97, '2015-01-12', '16:56', 44, 'Robyn Mills', '', 0, 18, 'Edit Address', 18, 0, 0), 
(98, '2015-01-12', '16:57', 44, 'Robyn Mills', '', 40, 18, 'Edit Member', 0, 0, 0), 
(99, '2015-01-14', '17:35', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(100, '2015-01-14', '17:40', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(101, '2015-01-18', '09:16', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(102, '2015-01-18', '09:16', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(103, '2015-01-18', '09:38', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(104, '2015-01-18', '09:48', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(105, '2015-01-18', '14:10', 44, 'Robyn Mills', '', 0, 19, 'Added member id 19', 0, 0, 0), 
(106, '2015-01-28', '06:50', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(107, '2015-02-06', '08:15', 44, 'Robyn Mills', '', 0, 13, 'Edit Address', 13, 0, 0), 
(108, '2015-02-06', '08:21', 44, 'Robyn Mills', '', 0, 13, 'Edit Address', 13, 0, 0), 
(109, '2015-02-06', '08:59', 44, 'Robyn Mills', '', 0, 14, 'Edit Communication', 0, 14, 0), 
(110, '2015-02-07', '14:47', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(111, '2015-02-14', '08:54', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(112, '2015-02-14', '08:55', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(113, '2015-06-04', '07:02', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(114, '2015-06-04', '07:08', 44, 'Robyn Mills', '', 40, 17, 'Edit Member', 0, 0, 0), 
(115, '2015-06-04', '07:09', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(116, '2015-06-04', '07:13', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(117, '2015-06-04', '07:14', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(118, '2015-06-04', '07:14', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(119, '2015-06-04', '07:26', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(120, '2015-09-05', '18:45', 44, 'Robyn Mills', '', 40, 11, 'Edit Member', 0, 0, 0), 
(121, '2015-09-05', '18:45', 44, 'Robyn Mills', '', 40, 11, 'Edit Member', 0, 0, 0), 
(122, '2015-09-05', '18:45', 44, 'Robyn Mills', '', 40, 11, 'Edit Member', 0, 0, 0), 
(123, '2016-03-14', '06:51', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(124, '2016-03-14', '06:51', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(125, '2016-03-14', '06:52', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(126, '2016-04-09', '12:08', 44, 'Robyn Mills', '', 40, 20, 'Add Member', 0, 0, 0), 
(127, '2016-04-09', '12:08', 44, 'Robyn Mills', '', 40, 20, 'Edit Member', 0, 0, 0), 
(128, '2016-04-09', '12:11', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(129, '2016-07-02', '04:53', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(130, '2016-07-02', '07:38', 44, 'Robyn Mills', '', 40, 21, 'Edit Member', 0, 0, 0), 
(131, '2016-07-02', '07:41', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(132, '2016-07-04', '21:23', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(133, '2016-07-04', '21:24', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(134, '2016-07-04', '21:24', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(135, '2016-07-04', '21:24', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(136, '2016-07-04', '21:26', 44, 'Robyn Mills', '', 0, 6, 'Edit Communication', 0, 6, 0), 
(137, '2016-07-04', '21:26', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(138, '2016-07-04', '21:26', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(139, '2016-07-04', '21:27', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(140, '2016-07-04', '21:27', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(141, '2016-07-04', '21:27', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(142, '2016-07-04', '21:28', 44, 'Robyn Mills', '', 40, 6, 'Edit Member', 0, 0, 0), 
(143, '2016-07-04', '21:37', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Robyn\'s Records', 0, 0, 0), 
(144, '2016-07-04', '21:43', 44, 'Robyn Mills', '', 40, 21, 'Edit Member', 0, 0, 0), 
(145, '2016-07-04', '21:43', 44, 'Robyn Mills', '', 0, 21, 'Edit Address 20', 0, 0, 0), 
(146, '2016-07-04', '21:44', 44, 'Robyn Mills', '', 40, 21, 'Edit Member', 0, 0, 0), 
(147, '2016-07-04', '21:44', 44, 'Robyn Mills', '', 40, 21, 'Edit Member', 0, 0, 0), 
(148, '2016-08-14', '05:32', 44, 'Robyn Mills', '', 40, 22, 'Edit Member', 0, 0, 0), 
(149, '2016-08-28', '23:43', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(150, '2016-09-04', '23:22', 44, 'Robyn Mills', '', 40, 44, 'Edit Setup for Troglodite Technologies', 0, 0, 0), 
(151, '2016-09-07', '21:28', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(152, '2016-09-07', '21:28', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(153, '2016-09-07', '21:28', 44, 'Robyn Mills', '', 40, 11, 'Edit Member', 0, 0, 0), 
(154, '2016-09-07', '21:29', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(155, '2016-09-07', '21:30', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(156, '2016-09-07', '21:33', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(157, '2016-09-07', '21:36', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(158, '2016-09-07', '21:36', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(159, '2016-09-07', '21:45', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(160, '2016-09-07', '21:47', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(161, '2016-09-07', '21:47', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(162, '2016-09-07', '22:11', 44, 'Robyn Mills', '', 40, 8, 'Edit Member', 0, 0, 0), 
(163, '2016-09-07', '22:33', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(164, '2016-09-07', '22:36', 44, 'Robyn Mills', '', 40, 4, 'Edit Member', 0, 0, 0), 
(165, '2016-09-07', '22:43', 44, 'Robyn Mills', '', 40, 9, 'Edit Member', 0, 0, 0), 
(166, '2016-09-09', '16:46', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(167, '2016-09-09', '16:47', 44, 'Robyn Mills', '', 0, 7, 'Edit Address 5', 0, 0, 0), 
(168, '2016-09-11', '18:24', 44, 'Robyn Mills', '', 40, 3, 'Edit Member', 0, 0, 0), 
(169, '2016-09-15', '19:28', 44, 'Robyn Mills', '', 40, 9, 'Edit Member', 0, 0, 0), 
(170, '2016-09-23', '17:58', 44, 'Robyn Mills', '', 40, 3, 'Edit Member', 0, 0, 0), 
(171, '2016-09-23', '18:00', 44, 'Robyn Mills', '', 0, 3, 'Edit Address 2', 0, 0, 0), 
(172, '2016-09-23', '18:02', 44, 'Robyn Mills', '', 40, 3, 'Edit Member', 0, 0, 0), 
(173, '2016-09-23', '18:29', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(174, '2016-09-23', '18:34', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0), 
(175, '2016-09-23', '18:34', 44, 'Robyn Mills', '', 40, 7, 'Edit Member', 0, 0, 0);

-- # Tabel structure for table `boxes`
DROP TABLE  IF EXISTS `boxes`;
CREATE TABLE `boxes` (
  `box_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_office` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `from` mediumint(9) NOT NULL,
  `to` mediumint(9) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  `boxbag` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `c_menu`
DROP TABLE  IF EXISTS `c_menu`;
CREATE TABLE `c_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `morder` smallint(4) NOT NULL,
  `level` tinyint(2) NOT NULL,
  `label` varchar(50) NOT NULL DEFAULT '',
  `onclick` text,
  `tooltip` varchar(250) NOT NULL DEFAULT '',
  `image_file` blob NOT NULL,
  `facility` char(2) NOT NULL DEFAULT '',
  `a1` char(1) NOT NULL DEFAULT 'N',
  `a2` char(1) NOT NULL DEFAULT 'N',
  `a3` char(1) NOT NULL DEFAULT 'N',
  `a4` char(1) NOT NULL DEFAULT 'N',
  `a5` char(1) NOT NULL DEFAULT 'N',
  `a6` char(1) NOT NULL DEFAULT 'N',
  `a7` char(1) NOT NULL DEFAULT 'N',
  `a8` char(1) NOT NULL DEFAULT 'N',
  `a9` char(1) NOT NULL DEFAULT 'N',
  `a10` char(1) NOT NULL DEFAULT 'N',
  `a11` char(1) NOT NULL DEFAULT 'N',
  `a12` char(1) NOT NULL DEFAULT 'N',
  `a13` char(1) NOT NULL DEFAULT 'N',
  `a14` char(1) NOT NULL DEFAULT 'N',
  `a15` char(1) NOT NULL DEFAULT 'N',
  `a16` char(1) NOT NULL DEFAULT 'N',
  `a17` char(1) NOT NULL DEFAULT 'N',
  `a18` char(1) NOT NULL DEFAULT 'N',
  `a19` char(1) NOT NULL DEFAULT 'N',
  `a20` char(1) NOT NULL DEFAULT 'Y',
  `std_sub` char(1) NOT NULL DEFAULT 'N',
  `extra_1` char(1) NOT NULL DEFAULT 'N',
  `extra_2` char(1) NOT NULL DEFAULT 'N',
  `extra_3` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `c_menu` (`menu_id`, `morder`, `level`, `label`, `onclick`, `tooltip`, `image_file`, `facility`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `a7`, `a8`, `a9`, `a10`, `a11`, `a12`, `a13`, `a14`, `a15`, `a16`, `a17`, `a18`, `a19`, `a20`, `std_sub`, `extra_1`, `extra_2`, `extra_3`) VALUES (1, 1, 0, 'Members', '', 'Clients Menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'N', 'N', 'Y'), 
(3, 3, 1, 'Administer Members', 'javascript:createTab(\'updtmembers.php\',\'Add/Edit/Delete Member Records\',0)', 'Add/Edit/Delete Member Records', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(5, 5, 0, 'Marketing', '', 'Marketing Functions', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'Y'), 
(6, 6, 1, 'Campaign Administration', '', 'Campaign Functions', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(7, 7, 2, 'Update Campaigns', 'javascript:createTab(\'updtcampaigns.php\',\'Update Campaign Data\',0)', 'Update Campaign Data', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(8, 8, 2, 'Run Campaign', 'javascript:createTab(\'runcampaign.php\',\'Run a Campaign\',0)', 'Run a Campaign', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(9, 9, 2, 'Update Outsource Providers', 'javascript:createTab(\'updtoutprov.php\',\'Add/Edit/Delete Outsoruce Providers\',0)', 'Add/Edit/Delete Outsoruce Providers', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(10, 10, 2, 'Campaign Statistics', '', 'Report on campaign statistics', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(11, 11, 3, 'By Campaign/Outsource', 'javascript:createTab(\'campstats.php\',\'Report on campaign statistics by campaign/outsource\',0)', 'Report on campaign statistics by campaign/outsource', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'Y', 'N', 'N'), 
(12, 12, 2, 'Update Marketers', 'javascript:createTab(\'updtmarketers.php\',\'Add/Edit/Delete Marketers and their Staff\',0)', 'Add/Edit/Delete Marketers and their Staff', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'N', 'N', 'N', 'Y'), 
(13, 13, 0, 'Administrative Tools', '', 'Administrative Tools Menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(14, 14, 1, 'Update Workflow Stages', 'javascript:createTab(\'updtworkflow.php\',\'Update Workflow Stages\',0)', 'Update list of workflow stages', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(15, 15, 1, 'Duplicate Member Records', 'javascript:createTab(\'listduplicates.php\',\'List Duplicate member records\',0)', 'List Duplicate member records', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(16, 16, 1, 'Update Client Types', 'javascript:createTab(\'updtclienttypes.php\',\'Update Client Types\',0)', 'Update Client Types', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(17, 17, 1, 'Update Industries', 'javascript:createTab(\'updtindustries.php\',\'Update Industry Types\',0)', 'Update Industry Types', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(18, 18, 1, 'Update Accounting Categories', 'javascript:createTab(\'updtacccats.php\',\'Update Accounting Categories\',0)', 'Update Accounting Categories', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(19, 19, 0, 'Complaints Register', '', '', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(20, 20, 1, 'Administer Complaints', 'javascript:createTab(\'complaints.php\',\'List and update complaints\',0)', 'List and update complaints', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', 'Y', 'N', 'N', 'N'), 
(21, 21, 0, 'Housekeeping', '', 'Housekeeping menu', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(22, 22, 1, 'Setup Company Details', 'javascript:createTab(\'../fin/hs_setup.php\',\'Setup Company Details\',0)', 'Setup Company Details', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(23, 23, 1, 'Update Users', 'javascript:createTab(\'hs_users.php\',\'Update users\',0)', 'Assign passwords to users and users to menu groups.', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(24, 24, 1, 'Update Menu Groups', 'javascript:createTab(\'hs_updtmeng.php\',\'Update Menu Groups\',0)', 'Assign menu options to groups of users.', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(25, 25, 1, 'Backup', 'javascript:createTab(\'../includes/bkup/backup.php\',\'Backup\',0)', 'Backup database for this company', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', ''), 
(26, 26, 1, 'Restore', 'javascript:createTab(\'../includes/bkup/rbkup.php\',\'Restore from Backup\',0)', 'Restore from backup', '', '*', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'Y', '', '', '', '');

-- # Tabel structure for table `campaign_costs`
DROP TABLE  IF EXISTS `campaign_costs`;
CREATE TABLE `campaign_costs` (
  `costs_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `item` varchar(70) NOT NULL,
  `cost` decimal(16,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`costs_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `campaign_docs`
DROP TABLE  IF EXISTS `campaign_docs`;
CREATE TABLE `campaign_docs` (
  `campdoc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date NOT NULL,
  `doc` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`campdoc_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `campaigns`
DROP TABLE  IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `campaign_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(45) NOT NULL,
  `startdate` date NOT NULL DEFAULT '0000-00-00',
  `staff` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `goals` text NOT NULL,
  `outprov_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`campaign_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `candidates`
DROP TABLE  IF EXISTS `candidates`;
CREATE TABLE `candidates` (
  `candidate_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) NOT NULL DEFAULT '0',
  `campaign_id` int(11) NOT NULL DEFAULT '0',
  `cand_status` char(1) NOT NULL DEFAULT 'A',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `lastname` varchar(45) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `preferred` varchar(50) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `workflow` varchar(45) NOT NULL,
  `candstatus` varchar(10) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`candidate_id`),
  KEY `sub_id` (`sub_id`),
  KEY `member_id` (`member_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `client_company_xref`
DROP TABLE  IF EXISTS `client_company_xref`;
CREATE TABLE `client_company_xref` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL DEFAULT '0',
  `company_id` int(10) unsigned NOT NULL DEFAULT '0',
  `drno` int(10) unsigned NOT NULL DEFAULT '0',
  `crno` int(10) unsigned NOT NULL DEFAULT '0',
  `drsub` int(2) NOT NULL DEFAULT '0',
  `crsub` int(2) NOT NULL DEFAULT '0',
  `subname` varchar(45) NOT NULL DEFAULT '',
  `hs_contractor` int(11) NOT NULL DEFAULT '0',
  `blocked` char(3) NOT NULL DEFAULT 'No',
  `sortcode` varchar(45) NOT NULL DEFAULT '',
  `current` double(16,2) NOT NULL DEFAULT '0.00',
  `d30` double(16,2) NOT NULL DEFAULT '0.00',
  `d60` double(16,2) NOT NULL DEFAULT '0.00',
  `d90` double(16,2) NOT NULL DEFAULT '0.00',
  `d120` double(16,2) NOT NULL DEFAULT '0.00',
  `tcur` double(16,2) NOT NULL DEFAULT '0.00',
  `t30` double(16,2) NOT NULL DEFAULT '0.00',
  `t60` double(16,2) NOT NULL DEFAULT '0.00',
  `t90` double(16,2) NOT NULL DEFAULT '0.00',
  `t120` double(16,2) NOT NULL DEFAULT '0.00',
  `limit` int(4) NOT NULL,
  `monlimit` double(16,2) NOT NULL DEFAULT '0.00',
  `sellprice` int(4) NOT NULL,
  `priceband` int(11) NOT NULL DEFAULT '1',
  `sendstatement` char(5) NOT NULL DEFAULT 'Post',
  `billing` int(11) NOT NULL DEFAULT '0',
  `email` int(11) NOT NULL DEFAULT '0',
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `member` varchar(75) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `client_company_xref` (`uid`, `client_id`, `company_id`, `drno`, `crno`, `drsub`, `crsub`, `subname`, `hs_contractor`, `blocked`, `sortcode`, `current`, `d30`, `d60`, `d90`, `d120`, `tcur`, `t30`, `t60`, `t90`, `t120`, `limit`, `monlimit`, `sellprice`, `priceband`, `sendstatement`, `billing`, `email`, `lastupdated`, `member`) VALUES (3, 5, 19, 30000005, 0, 0, 0, '', 0, 'No', 'Itron30000005-0', -492, 1004.92, -885.55, 1003.65, 224.25, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 10, 0, '2016-11-07 03:43:25', 'Itron '), 
(4, 3, 19, 30000003, 0, 0, 0, '', 0, 'Yes', 'Kostrencic30000003-0', 0, 0, -431.25, 431.25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-09-23 17:59:29', 'Kostrencic Ivan'), 
(5, 4, 19, 30000004, 0, 0, 0, '', 0, 'No', 'Kostrencic30000004-0', -200, -1.33, 1.33, -6.9, 6.9, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 9, 0, '2015-02-07 11:43:06', 'Kostrencic Boris'), 
(6, 6, 19, 30000006, 0, 0, 0, '', 0, 'No', 'Mills30000006-0', -30, 0, 41.57, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 22, 0, '2016-07-04 21:27:41', 'Mills Robyn'), 
(7, 7, 19, 30000007, 0, 0, 0, '', 0, 'No', 'Dickinson30000007-0', -792.74, 866.32, 52.66, -66.22, 196.42, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'Post', 5, 0, '2016-09-09 17:29:05', 'Dickinson Danielle'), 
(8, 8, 19, 30000008, 0, 0, 0, '', 0, 'No', 'Bon Marche30000008-0', 151.48, 0, 279.01, 126.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 6, 0, '2016-09-07 21:49:56', 'Bon Marche '), 
(9, 9, 19, 0, 20000009, 0, 0, '', 0, 'No', 'Bunnings20000009-0', -2691.7, 0, 400, -400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-09-23 18:28:13', 'Bunnings '), 
(10, 10, 19, 0, 20000010, 0, 0, '', 0, 'No', 'Jaggers20000010-0', -439.56, 304, -744.75, 85.1, -1644.5, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2015-06-04 07:16:42', 'Jaggers '), 
(11, 11, 19, 0, 20000011, 0, 0, '', 0, 'No', 'CashWholesalers20000011-0', 123.9, 211, -132.36, -1575.39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 11, 0, '2015-02-07 15:46:52', 'CashWholesalers '), 
(12, 12, 19, 0, 20000012, 0, 0, '', 0, 'No', 'Nyore20000012-0', 0, 0, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2015-02-07 11:43:06', 'Nyore Nyore'), 
(13, 13, 19, 0, 20000013, 0, 0, '', 0, 'No', 'Iridium20000013-0', -552.05, 0, -810.45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 13, 0, '2015-12-01 09:50:51', 'Iridium '), 
(14, 8, 20, 0, 20000008, 0, 0, '', 0, 'No', 'Bon Marche20000008-0', 0, 0, 0, 0, -129.81, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-04-09 12:34:08', 'Bon Marche '), 
(15, 9, 20, 0, 20000009, 0, 0, '', 0, 'No', 'Bunnings20000009-0', 0, 0, 0, 0, -4950, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-04-09 12:34:08', 'Bunnings '), 
(16, 11, 20, 0, 20000011, 0, 0, '', 0, 'No', 'CashWholesalers20000011-0', 0, 0, 0, 0, 95.2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-04-09 12:34:08', 'CashWholesalers '), 
(17, 14, 20, 30000014, 0, 0, 0, '', 0, 'No', 'Reeves30000014-0', 0, 0, 0, -3000, 7500, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 15, 0, '2016-07-04 21:38:35', 'Reeves Julian'), 
(18, 15, 20, 0, 20000015, 0, 0, '', 0, 'No', 'Phoenix Legal20000015-0', 0, 0, 0, 0, -317.5, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-04-09 12:34:08', 'Phoenix Legal '), 
(19, 4, 20, 30000004, 0, 0, 0, '', 0, 'No', 'Kostrencic30000004-0', 125.85, 0, 0, 0, 850.99, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 9, 0, '2016-09-25 18:24:23', 'Kostrencic Boris'), 
(20, 16, 20, 30000016, 0, 0, 0, '', 0, 'No', 'Rogers30000016-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 16, 0, '2015-09-20 17:08:07', 'Rogers Karen'), 
(21, 17, 20, 30000017, 0, 0, 0, '', 0, 'No', 'Ball30000017-0', 0, 0, 0, 0, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 17, 0, '2015-09-20 17:08:07', 'Ball Zoe'), 
(22, 18, 20, 30000018, 0, 0, 0, '', 0, 'No', 'Society30000018-0', 0, 0, 0, 0, 167.2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 18, 0, '2015-09-20 17:08:07', 'Cafe Society Cafe Society'), 
(23, 19, 20, 30000019, 0, 0, 0, '', 0, 'No', 'Wallap30000019-0', 0, 0, 0, 0, 315.02, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-04-03 10:12:52', 'Wallap Cods'), 
(24, 10, 20, 0, 20000010, 0, 0, '', 0, 'No', 'Jaggers20000010-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-03-14 19:17:34', 'Jaggers '), 
(25, 20, 20, 30000020, 0, 0, 0, '', 0, 'No', 'Murphy30000020-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-04-09 12:34:08', 'Murphy HM'), 
(26, 21, 20, 30000021, 0, 0, 0, '', 0, 'No', 'Roberts30000021-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 20, 0, '2016-07-22 01:02:49', 'Roberts Robin'), 
(27, 22, 20, 30000022, 0, 0, 0, '', 0, 'No', 'Mills30000022-0', 27.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-08-14 05:31:32', 'Mills'), 
(28, 9, 19, 30000009, 0, 0, 0, '', 0, 'No', 'Bunnings30000009-0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Post', 0, 0, '2016-09-07 22:46:42', 'Bunnings ');

-- # Tabel structure for table `client_types`
DROP TABLE  IF EXISTS `client_types`;
CREATE TABLE `client_types` (
  `client_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_type` varchar(15) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`client_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `client_types` (`client_type_id`, `client_type`, `sub_id`) VALUES (1, 'Sales', 40), 
(2, 'Services', 40), 
(3, 'Sales/Services', 40), 
(4, 'Training', 40), 
(5, 'Tenants', 40);

-- # Tabel structure for table `clienttype_xref`
DROP TABLE  IF EXISTS `clienttype_xref`;
CREATE TABLE `clienttype_xref` (
  `clienttype_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `client_type` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`clienttype_xref_id`),
  KEY `member_id` (`member_id`,`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `clienttype_xref` (`clienttype_xref_id`, `member_id`, `client_type`, `sub_id`) VALUES (1, 8, 'Sales/Services', 40);

-- # Tabel structure for table `comms`
DROP TABLE  IF EXISTS `comms`;
CREATE TABLE `comms` (
  `comms_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `comms_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `country_code` varchar(4) NOT NULL,
  `area_code` varchar(4) NOT NULL DEFAULT ' ',
  `comm` varchar(75) NOT NULL DEFAULT ' ',
  `comm2` varchar(75) NOT NULL,
  `preferred` char(1) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `billing` char(1) NOT NULL DEFAULT 'N',
  `delivery` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`comms_id`),
  KEY `member_id` (`member_id`),
  KEY `comm2` (`comm2`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `comms` (`comms_id`, `member_id`, `staff_id`, `comms_type_id`, `country_code`, `area_code`, `comm`, `comm2`, `preferred`, `sub_id`, `billing`, `delivery`) VALUES (3, 3, 0, 3, '++', 7, 54795534, 54795534, '', 0, 'N', 'N'), 
(4, 4, 0, 3, 64, 9, 1111, 1111, '', 0, 'N', 'N'), 
(5, 5, 0, 2, 64, 9, 991199, 991199, '', 0, 'N', 'N'), 
(6, 6, 0, 1, 0, 44, 7931310636, 7931310636, '', 0, 'N', 'N'), 
(7, 7, 0, 2, 61, 7, 3535353, 3535353, '', 0, 'N', 'N'), 
(8, 8, 0, 2, 61, 7, 8888, 8888, '', 0, 'N', 'N'), 
(9, 9, 0, 2, 61, 7, 555, 555, '', 0, 'N', 'N'), 
(10, 10, 0, 2, 61, 7, 87878, 87878, '', 0, 'N', 'N'), 
(11, 11, 0, 2, '00 6', 7, 112233, 112233, '', 0, 'N', 'N'), 
(12, 12, 0, 2, 61, 9, 556887, 556887, '', 0, 'N', 'N'), 
(13, 13, 0, 2, '00 6', 9, 12345, 12345, '', 0, 'N', 'N'), 
(14, 14, 0, 4, '', '', 'robyn@infin8integr8.com', 'robyn@infin8integr8.com', 'Y', 0, 'N', 'N'), 
(15, 15, 0, 2, '++', 9, 12345, 12345, '', 0, 'N', 'N'), 
(16, 16, 0, 2, '+', 9, 2211332, 2211332, '', 0, 'N', 'N'), 
(17, 17, 44, 2, 61, 7, 11131, 11131, '', 0, 'N', 'N'), 
(18, 18, 0, 2, 61, 9, 9876, 9876, '', 0, 'N', 'N'), 
(19, 19, 0, 3, 61, '', 40709888, 40709888, '', 0, 'N', 'N'), 
(20, 21, 0, 1, 44, 1452, 812512, 812512, '', 0, '', 'N'), 
(21, 22, 0, 0, '', '', '', '', '', 0, '', 'N');

-- # Tabel structure for table `comms_type`
DROP TABLE  IF EXISTS `comms_type`;
CREATE TABLE `comms_type` (
  `comms_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comm_type` varchar(45) NOT NULL,
  PRIMARY KEY (`comms_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `comms_type` (`comms_type_id`, `comm_type`) VALUES (1, 'Phone Home'), 
(2, 'Phone Work'), 
(3, 'Mobile'), 
(4, 'Email'), 
(5, 'Skype'), 
(6, 'Fax Work'), 
(7, 'Fax Home'), 
(8, 'After Hours'), 
(9, 'Facebook'), 
(10, 'Twitter'), 
(11, 'Web');

-- # Tabel structure for table `companies`
DROP TABLE  IF EXISTS `companies`;
CREATE TABLE `companies` (
  `company_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(45) NOT NULL,
  `db_name` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `business_number` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `complaint_nature`
DROP TABLE  IF EXISTS `complaint_nature`;
CREATE TABLE `complaint_nature` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `nature` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `complaint_nature` (`uid`, `nature`) VALUES (1, 'Customer Service'), 
(2, 'Faulty Item');

-- # Tabel structure for table `complaints`
DROP TABLE  IF EXISTS `complaints`;
CREATE TABLE `complaints` (
  `complaint_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `complainant` varchar(50) NOT NULL,
  `against` varchar(50) NOT NULL,
  `received` date NOT NULL DEFAULT '0000-00-00',
  `via` varchar(20) NOT NULL,
  `acknowledged` date NOT NULL DEFAULT '0000-00-00',
  `closed` date NOT NULL DEFAULT '0000-00-00',
  `compensation` decimal(16,2) NOT NULL DEFAULT '0.00',
  `medium` varchar(50) NOT NULL,
  `source` varchar(50) NOT NULL,
  `nature` varchar(50) NOT NULL,
  `product` varchar(100) NOT NULL,
  `taken_by` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `outcome` text NOT NULL,
  `notes` text NOT NULL,
  `responded` date NOT NULL DEFAULT '0000-00-00',
  `cause` varchar(100) NOT NULL,
  `further_action` text NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `documents`
DROP TABLE  IF EXISTS `documents`;
CREATE TABLE `documents` (
  `doc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date NOT NULL,
  `doc` varchar(100) NOT NULL,
  `staff` varchar(45) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`doc_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `emails`
DROP TABLE  IF EXISTS `emails`;
CREATE TABLE `emails` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `email_date` date NOT NULL DEFAULT '0000-00-00',
  `email_from` varchar(45) NOT NULL,
  `email_subject` varchar(45) NOT NULL,
  `email_message` text NOT NULL,
  `email_time` char(8) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `emails2send`
DROP TABLE  IF EXISTS `emails2send`;
CREATE TABLE `emails2send` (
  `email_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email_date` date NOT NULL DEFAULT '0000-00-00',
  `email_from` varchar(70) NOT NULL,
  `email_to` varchar(70) NOT NULL,
  `cc` varchar(300) NOT NULL,
  `email_subject` varchar(70) NOT NULL,
  `email_message` text NOT NULL,
  `sent` char(1) NOT NULL DEFAULT 'N',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `email_date` (`email_date`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `industries`
DROP TABLE  IF EXISTS `industries`;
CREATE TABLE `industries` (
  `industry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `industry` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`industry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `industries` (`industry_id`, `industry`, `sub_id`) VALUES (1, 'Technical', 40), 
(2, 'Training', 40), 
(3, 'Wholesale', 40);

-- # Tabel structure for table `links`
DROP TABLE  IF EXISTS `links`;
CREATE TABLE `links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `members`
DROP TABLE  IF EXISTS `members`;
CREATE TABLE `members` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alt_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(45) NOT NULL DEFAULT '',
  `middlename` varchar(45) NOT NULL,
  `preferredname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL DEFAULT '',
  `dob` date NOT NULL,
  `gender` char(6) NOT NULL,
  `title` char(9) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `client_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `age` smallint(3) unsigned NOT NULL,
  `checked` char(3) NOT NULL DEFAULT 'No',
  `occupation` varchar(45) NOT NULL,
  `industry_id` int(11) NOT NULL,
  `position` varchar(45) NOT NULL,
  `dependant` char(1) NOT NULL DEFAULT 'N',
  `staff` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `next_meeting` date NOT NULL DEFAULT '0000-00-00',
  `client_type` varchar(20) NOT NULL,
  PRIMARY KEY (`member_id`),
  KEY `lastname` (`lastname`),
  KEY `dob` (`dob`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `members` (`member_id`, `alt_id`, `firstname`, `middlename`, `preferredname`, `lastname`, `dob`, `gender`, `title`, `sub_id`, `client_type_id`, `age`, `checked`, `occupation`, `industry_id`, `position`, `dependant`, `staff`, `status`, `next_meeting`, `client_type`) VALUES (3, 0, 'Ivan', '', '', 'Kostrencic', '1934-05-05', 'Male', 'Mr', 40, 0, 80, 'No', 'Retired', 0, '', 'N', 'Robyn Mills', ' ', '0000-00-00', ''), 
(4, 0, 'Boris', 'Simon', '', 'Kostrencic', '1966-06-14', 'Male', 'Mr', 40, 0, 48, 'No', 'Technical engineer', 0, 'Senior sales rep', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(5, 0, '', '', '', 'Itron', '0000-00-00', 'Male', 'Mr', 40, 0, 2014, 'No', '', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ''), 
(6, 0, 'Robyn', 'Jean', '', 'Mills', '1965-03-03', 'Female', 'Mrs', 40, 0, 51, 'No', 'Bookkeeper', 0, 'Bookkeeper', 'N', 'Robyn Mills', 'Lead', '0000-00-00', ''), 
(7, 0, 'Danielle', 'Lesley', '', 'Dickinson', '1968-02-02', 'Female', 'Mrs', 40, 0, 48, 'Yes', 'PA', 0, 'PA', 'N', 'Robyn Mills', 'Lead', '0000-00-00', ''), 
(8, 0, '', '', '', 'Bon Marche', '0000-00-00', 'Male', 'Mr', 40, 0, 2015, 'Yes', '', 3, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', ' '), 
(9, 0, '', '', '', 'Bunnings', '0000-00-00', 'Male', 'Mr', 40, 0, 2014, 'Yes', '', 0, '', 'N', 'Robyn Mills', 'Supplier', '0000-00-00', ''), 
(10, 0, '', '', '', 'Jaggers', '0000-00-00', 'Male', 'Mr', 40, 0, 2014, 'Yes', '', 0, '', 'N', 'Robyn Mills', 'Supplier', '0000-00-00', ''), 
(11, 0, '', '', '', 'CashWholesalers', '0000-00-00', 'Male', 'Mr', 40, 0, 2015, 'Yes', '', 0, '', 'N', 'Robyn Mills', 'Supplier', '0000-00-00', ' '), 
(12, 0, 'Nyore', '', '', 'Nyore', '0000-00-00', 'Male', 'Mr', 40, 0, 0, 'No', '', 0, '', 'N', 0, '', '0000-00-00', ''), 
(13, 0, '', '', '', 'Iridium', '0000-00-00', 'Male', 'Mr', 40, 0, 0, 'No', '', 0, '', 'N', 0, '', '0000-00-00', ''), 
(14, 0, 'Julian', '', '', 'Reeves', '0000-00-00', 'Male', 'Mr', 40, 0, 2015, 'No', 'Distributor', 0, 'Director', 'N', 'Robyn Mills', 'Client', '0000-00-00', ' '), 
(15, 0, '', '', '', 'Phoenix Legal', '0000-00-00', 'Male', 'Mr', 40, 0, 0, 'No', 'Solicitors', 0, '', 'N', 'Robyn Mills', '', '0000-00-00', ''), 
(16, 0, 'Karen', '', '', 'Rogers', '1965-11-19', 'Female', 'Mrs', 40, 0, 49, 'No', 'Accounts Manager', 3, '', 'N', 'Robyn Mills', '', '0000-00-00', ''), 
(17, 0, 'Zoe', '', '', 'Ball', '1963-01-01', 'Female', 'Ms', 40, 0, 52, 'Yes', 'Dancer', 0, '', 'N', 'Robyn Mills', 'Client', '0000-00-00', 'Tenants'), 
(18, 0, 'Cafe Society', '', 'Cafe Society', 'Cafe Society', '0000-00-00', 'Male', 'Mr', 40, 0, 2015, 'Yes', 'Coffee shop', 0, '', 'N', 'Robyn Mills', ' ', '0000-00-00', ' '), 
(19, 0, 'Cods', '', '', 'Wallap', '1950-04-05', 'Male', 'Mr', 40, 0, 64, 'No', 'Comedian', 2, '', 'N', 0, '', '0000-00-00', ''), 
(20, 0, 'HM', '', '', 'Murphy', '1950-05-01', 'Male', 'Mr', 40, 0, 65, 'No', 'Retail', 0, 'Manager', 'N', 'Robyn Mills', '', '0000-00-00', ''), 
(21, 0, 'Robin', '', '', 'Roberts', '0000-00-00', 'Male', 'Mr', 40, 0, 2016, 'No', 'Architect', 0, '', 'N', 'Robyn Mills', 'Lead', '0000-00-00', ''), 
(22, 0, 'Monica', '', '', 'Mills', '0000-00-00', 'Female', 'Mrs', 40, 0, 0, 'No', 'Teacher', 0, '', 'N', 0, 'Lead', '0000-00-00', '');

-- # Tabel structure for table `outprovs`
DROP TABLE  IF EXISTS `outprovs`;
CREATE TABLE `outprovs` (
  `outprov_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(45) NOT NULL,
  `sub_id` int(10) unsigned NOT NULL DEFAULT '0',
  `phone` varchar(30) NOT NULL,
  `address` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `web` varchar(70) NOT NULL,
  PRIMARY KEY (`outprov_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `quotelines`
DROP TABLE  IF EXISTS `quotelines`;
CREATE TABLE `quotelines` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL DEFAULT '0',
  `itemcode` varchar(30) NOT NULL,
  `quantity` decimal(9,3) NOT NULL DEFAULT '0.000',
  `price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `taxtype` char(3) NOT NULL DEFAULT '',
  `taxpcent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(16,2) NOT NULL DEFAULT '0.00',
  `taxindex` int(11) NOT NULL,
  `disc_type` char(1) NOT NULL DEFAULT '',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `ref_no` char(15) NOT NULL,
  `item` varchar(45) NOT NULL DEFAULT '',
  `unit` char(4) NOT NULL DEFAULT '',
  `value` decimal(16,2) NOT NULL DEFAULT '0.00',
  `supplier` int(11) NOT NULL DEFAULT '0',
  `currency` char(3) NOT NULL DEFAULT '',
  `sub` int(11) NOT NULL DEFAULT '0',
  `consign` char(1) NOT NULL DEFAULT '',
  `rate` decimal(7,3) NOT NULL DEFAULT '0.000',
  `grnlineno` int(11) NOT NULL,
  `paid` decimal(16,2) NOT NULL DEFAULT '0.00',
  `note` text NOT NULL,
  `sent` decimal(16,2) NOT NULL DEFAULT '0.00',
  `dn` varchar(15) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `quotelines` (`uid`, `quote_id`, `itemcode`, `quantity`, `price`, `taxtype`, `taxpcent`, `tax`, `taxindex`, `disc_type`, `discount`, `ref_no`, `item`, `unit`, `value`, `supplier`, `currency`, `sub`, `consign`, `rate`, `grnlineno`, `paid`, `note`, `sent`, `dn`) VALUES (1, 0, 'GDVD', 20, 40, 'GST', 10, 80, 1, '%', 0, 'QOT1', 'DVD Games', 'each', 800, 0, '', 0, '', 0, 1, 0, '', 0, ''), 
(2, 2, 'APRIC', 2, 4, 'GST', 10, 0.8, 1, '%', 0, 'QOT1', 'Apricot Jam', 'Bott', 8, 0, '', 0, '', 0, 1, 0, '', 0, ''), 
(3, 3, 'KEY', 2, 40, 'GST', 10, 8, 1, '%', 0, 'QOT2', 'Keyboards', 'each', 80, 0, '', 0, '', 0, 1, 0, '', 0, ''), 
(4, 4, 'MON', 1, 125.43, 'GST', 10, 12.54, 1, '%', 0, 'QOT3', 'Monitors', 'each', 125.43, 0, '', 0, '', 0, 1, 0, '', 0, ''), 
(5, 5, 'TV', 1, 617.5, 'GST', 10, 60.52, 1, '%', 12.35, 'QOT5', 'TV', 'set', 605.15, 0, '', 0, '', 0, 1, 0, '', 0, ''), 
(6, 5, 'PROG', 2, 55, 'GST', 10, 11, 1, '%', 0, 'QOT5', 'Programming', 'Hour', 110, 0, '', 0, '', 0, 2, 0, '', 0, '');

-- # Tabel structure for table `quotes`
DROP TABLE  IF EXISTS `quotes`;
CREATE TABLE `quotes` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `coy_id` int(11) NOT NULL DEFAULT '0',
  `accountno` int(11) NOT NULL DEFAULT '0',
  `branch` char(4) NOT NULL DEFAULT '',
  `sub` int(11) NOT NULL DEFAULT '0',
  `gldesc` char(40) NOT NULL DEFAULT '',
  `invno` int(11) NOT NULL DEFAULT '0',
  `ref_no` char(15) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  `totvalue` double(16,2) NOT NULL DEFAULT '0.00',
  `tax` double(16,2) NOT NULL DEFAULT '0.00',
  `cash` double(16,2) NOT NULL DEFAULT '0.00',
  `cheque` double(16,2) NOT NULL DEFAULT '0.00',
  `eftpos` double(16,2) NOT NULL DEFAULT '0.00',
  `ccard` double(16,2) NOT NULL DEFAULT '0.00',
  `staff` varchar(45) NOT NULL,
  `xref` char(15) NOT NULL DEFAULT '',
  `postaladdress` varchar(100) NOT NULL,
  `deliveryaddress` varchar(100) NOT NULL,
  `client` varchar(80) NOT NULL,
  `note` text NOT NULL,
  `coyname` varchar(50) NOT NULL,
  `invref` varchar(15) NOT NULL,
  `currency` char(3) NOT NULL,
  `rate` decimal(7,3) NOT NULL DEFAULT '1.000',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `quotes` (`uid`, `member_id`, `coy_id`, `accountno`, `branch`, `sub`, `gldesc`, `invno`, `ref_no`, `ddate`, `totvalue`, `tax`, `cash`, `cheque`, `eftpos`, `ccard`, `staff`, `xref`, `postaladdress`, `deliveryaddress`, `client`, `note`, `coyname`, `invref`, `currency`, `rate`) VALUES (1, 8, 19, 30000008, '', 0, 'DVDs', 1, 'QOT1', '2015-06-03', 800, 80, 0, 0, 0, 0, 'Robyn Mills', 'S_O1', 'The Plaza,Sunshine Street,Cbd,Maroochydore', 'The Plaza,Sunshine Street,Cbd,Maroochydore', 'Bon Marche  ', 'Game of thrones dvds', 'Troglodite Technologies', '', '', 1), 
(2, 4, 20, 30000004, '', 0, 'test quote print', 1, 'QOT1', '2016-09-07', 8, 0.8, 0, 0, 0, 0, 'Robyn Mills', '', '1/79 Rosedale Road,Albany,Brisbane,4069', '1/79 Rosedale Road,Albany,Brisbane,4069', 'Kostrencic Boris ', 'testing', 'Robyn\'s Records', '', '', 1), 
(3, 9, 19, 30000009, '', 0, 'test quote', 2, 'QOT2', '2016-09-07', 80, 8, 0, 0, 0, 0, 'Robyn Mills', 'S_O2', '1 Homemaker Centre,Maroochydore,Qld,4558', '1 Homemaker Centre,Maroochydore,Qld,4558', 'Bunnings ', '', 'Troglodite Technologies', '', '', 1), 
(4, 9, 19, 30000009, '', 0, 'more test quote', 3, 'QOT3', '2016-09-07', 125.43, 12.54, 0, 0, 0, 0, 'Robyn Mills', '', '1 Homemaker Centre,Maroochydore,Qld,4558', '1 Homemaker Centre,Maroochydore,Qld,4558', 'Bunnings  ', '', 'Troglodite Technologies', '', '', 1), 
(5, 7, 19, 30000007, '', 0, 'TV Set', 5, 'QOT5', '2016-09-15', 715.15, 71.52, 0, 0, 0, 0, 'Robyn Mills', 'S_O5', '', '', 'Danielle Dickinson', 'Panasonic 22 inch', 'Troglodite Technologies', '', '', 1);

-- # Tabel structure for table `referrals`
DROP TABLE  IF EXISTS `referrals`;
CREATE TABLE `referrals` (
  `referral_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(10) DEFAULT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `middlename` varchar(45) DEFAULT NULL,
  `preferred` varchar(45) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `commtype` int(11) NOT NULL DEFAULT '0',
  `country` varchar(45) DEFAULT NULL,
  `area` varchar(10) DEFAULT NULL,
  `comm` varchar(80) DEFAULT NULL,
  `commtype2` int(11) NOT NULL,
  `country2` varchar(45) DEFAULT NULL,
  `area2` varchar(10) DEFAULT NULL,
  `comm2` varchar(80) DEFAULT NULL,
  `location` varchar(20) DEFAULT NULL,
  `addresstype` int(11) NOT NULL DEFAULT '0',
  `streetno` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `suburb` varchar(50) DEFAULT NULL,
  `town` varchar(50) DEFAULT NULL,
  `postcode` varchar(6) DEFAULT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `ddate` date DEFAULT NULL,
  `referred_id` int(11) NOT NULL DEFAULT '0',
  `phoned` char(3) NOT NULL DEFAULT 'No',
  `phcounted` char(1) NOT NULL DEFAULT 'N',
  `note` text NOT NULL,
  PRIMARY KEY (`referral_id`),
  KEY `lastname` (`lastname`),
  KEY `comm` (`comm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referrals_phone`
DROP TABLE  IF EXISTS `referrals_phone`;
CREATE TABLE `referrals_phone` (
  `ref_phone_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ddate` date NOT NULL,
  `ttime` char(11) NOT NULL,
  `referral_id` int(11) NOT NULL DEFAULT '0',
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ref_phone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `referred`
DROP TABLE  IF EXISTS `referred`;
CREATE TABLE `referred` (
  `referred_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referred` varchar(25) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`referred_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `rural`
DROP TABLE  IF EXISTS `rural`;
CREATE TABLE `rural` (
  `rural_id` int(11) NOT NULL AUTO_INCREMENT,
  `rd` mediumint(9) NOT NULL,
  `town` varchar(100) NOT NULL,
  `postcode` varchar(5) NOT NULL,
  PRIMARY KEY (`rural_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `sayings`
DROP TABLE  IF EXISTS `sayings`;
CREATE TABLE `sayings` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `heading` varchar(45) NOT NULL,
  `saying` varchar(400) NOT NULL,
  `credit` varchar(45) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `status`
DROP TABLE  IF EXISTS `status`;
CREATE TABLE `status` (
  `status_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `status` (`status_id`, `status`, `sub_id`) VALUES (1, 'Lead', 40), 
(2, 'Prospect', 40), 
(3, 'Client', 40), 
(4, 'Supplier', 40);

-- # Tabel structure for table `streets`
DROP TABLE  IF EXISTS `streets`;
CREATE TABLE `streets` (
  `street_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `street` varchar(45) NOT NULL,
  `suburb` varchar(45) NOT NULL,
  `area` varchar(45) NOT NULL,
  `postcode` varchar(4) NOT NULL,
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `subemails`
DROP TABLE  IF EXISTS `subemails`;
CREATE TABLE `subemails` (
  `subemail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(70) NOT NULL,
  `recipient` varchar(70) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`subemail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `tmp44_assocfile`
DROP TABLE  IF EXISTS `tmp44_assocfile`;
CREATE TABLE `tmp44_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `todo`
DROP TABLE  IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enter_date` date NOT NULL,
  `enter_staff` varchar(45) NOT NULL,
  `todo_by` varchar(45) NOT NULL,
  `complete_by` date NOT NULL,
  `task` varchar(250) NOT NULL,
  `done` char(3) NOT NULL DEFAULT 'No',
  `category` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`todo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `workflow`
DROP TABLE  IF EXISTS `workflow`;
CREATE TABLE `workflow` (
  `process_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `process` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `porder` int(10) NOT NULL DEFAULT '0',
  `aide_memoir` text NOT NULL,
  PRIMARY KEY (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `workflow_xref`
DROP TABLE  IF EXISTS `workflow_xref`;
CREATE TABLE `workflow_xref` (
  `workflow_xref_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `process` varchar(45) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `ddate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`workflow_xref_id`),
  KEY `member_id` (`member_id`),
  KEY `sub_id` (`sub_id`),
  KEY `process` (`process`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp44_assocfile`
DROP TABLE  IF EXISTS `ztmp44_assocfile`;
CREATE TABLE `ztmp44_assocfile` (
  `associd` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT '0',
  `assoc` varchar(30) DEFAULT '',
  `ofid` int(11) DEFAULT '0',
  `ofname` varchar(50) DEFAULT '',
  PRIMARY KEY (`associd`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ztmp44_assocfile` (`associd`, `mid`, `assoc`, `ofid`, `ofname`) VALUES (1, 7, 'Spouse', 4, 'Boris Kostrencic');

-- # Tabel structure for table `ztmp44_campfile`
DROP TABLE  IF EXISTS `ztmp44_campfile`;
CREATE TABLE `ztmp44_campfile` (
  `campaign_id` int(11) DEFAULT '0',
  `name` varchar(45) DEFAULT '',
  `startdate` date DEFAULT NULL,
  `staff` varchar(45) DEFAULT '',
  `description` text,
  `goals` text,
  `complete` decimal(5,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- # Tabel structure for table `ztmp44_quote`
DROP TABLE  IF EXISTS `ztmp44_quote`;
CREATE TABLE `ztmp44_quote` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `itemcode` varchar(30) DEFAULT '',
  `item` varchar(100) DEFAULT '',
  `price` decimal(16,2) DEFAULT '0.00',
  `unit` varchar(20) DEFAULT '',
  `quantity` decimal(16,2) DEFAULT '0.00',
  `tax` decimal(16,2) DEFAULT '0.00',
  `value` decimal(16,2) DEFAULT '0.00',
  `discount` decimal(16,2) DEFAULT '0.00',
  `disctype` char(1) DEFAULT '',
  `discamount` decimal(16,2) DEFAULT '0.00',
  `tot` decimal(16,2) DEFAULT '0.00',
  `taxindex` int(11) DEFAULT '0',
  `taxtype` char(3) DEFAULT '',
  `taxpcent` decimal(5,2) DEFAULT '0.00',
  `sellacc` int(11) DEFAULT '0',
  `sellbr` char(4) DEFAULT '',
  `sellsub` int(4) DEFAULT '0',
  `purchacc` int(11) DEFAULT '0',
  `purchbr` char(4) DEFAULT '',
  `purchsub` int(4) DEFAULT '0',
  `groupid` int(11) DEFAULT '0',
  `catid` int(11) DEFAULT '0',
  `loc` int(11) DEFAULT '0',
  `note` text,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `ztmp44_quote` (`uid`, `itemcode`, `item`, `price`, `unit`, `quantity`, `tax`, `value`, `discount`, `disctype`, `discamount`, `tot`, `taxindex`, `taxtype`, `taxpcent`, `sellacc`, `sellbr`, `sellsub`, `purchacc`, `purchbr`, `purchsub`, `groupid`, `catid`, `loc`, `note`) VALUES (5, 'TV', 'TV', 617.5, 'set', 1, 60.52, 605.15, 12.35, '%', 0, 665.67, 1, 'GST', 10, 0, '', 0, 0, '', 0, 0, 0, 0, ''), 
(6, 'PROG', 'Programming', 55, 'Hour', 2, 11, 110, 0, '%', 0, 121, 1, 'GST', 10, 0, '', 0, 0, '', 0, 0, 0, 0, '');

-- # Tabel structure for table `ztmp44_tasks`
DROP TABLE  IF EXISTS `ztmp44_tasks`;
CREATE TABLE `ztmp44_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- # Tabel structure for table `ztmp67_tasks`
DROP TABLE  IF EXISTS `ztmp67_tasks`;
CREATE TABLE `ztmp67_tasks` (
  `todo_id` int(11) DEFAULT NULL,
  `complete_by` date DEFAULT '0000-00-00',
  `task` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

SET FOREIGN_KEY_CHECKS = 1; 
COMMIT; 
SET AUTOCOMMIT = 1; 
